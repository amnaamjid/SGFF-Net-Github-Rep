#!/bin/bash
echo "============================================"
echo "  Building a native Mac app (.app)"
echo "  Run this on the Mac you want to build from"
echo "============================================"
echo ""

echo "Installing build requirements (one-time, may take a few minutes)..."
python3 -m pip install -r requirements.txt --quiet
python3 -m pip install pyinstaller --quiet
if [ $? -ne 0 ]; then
    echo ""
    echo "Something went wrong installing requirements."
    echo "Make sure Python 3 is installed (python3 --version) and try again."
    read -p "Press Enter to close..."
    exit 1
fi

echo ""
echo "Building DeepfakeAnnotator.app - this can take several minutes..."
echo ""
python3 -m PyInstaller --windowed --name DeepfakeAnnotator --collect-all PySide6 app.py

if [ ! -d "dist/DeepfakeAnnotator.app" ]; then
    echo ""
    echo "Build failed - DeepfakeAnnotator.app was not created."
    echo "Scroll up for the error message, or send it to the developer."
    read -p "Press Enter to close..."
    exit 1
fi

echo ""
echo "============================================"
echo "  Build succeeded!"
echo "============================================"
echo ""
echo "Preparing a ready-to-send folder: Distribution_ForAnnotators_Mac"
rm -rf "Distribution_ForAnnotators_Mac"
mkdir -p "Distribution_ForAnnotators_Mac"
cp -R "dist/DeepfakeAnnotator.app" "Distribution_ForAnnotators_Mac/"
mkdir -p "Distribution_ForAnnotators_Mac/Dataset" "Distribution_ForAnnotators_Mac/results" "Distribution_ForAnnotators_Mac/progress"
cp -R "Dataset/." "Distribution_ForAnnotators_Mac/Dataset/" 2>/dev/null
if [ -f "image_metadata.csv" ]; then
    cp "image_metadata.csv" "Distribution_ForAnnotators_Mac/"
fi
cp "ANNOTATOR_GUIDE_NoInstall.md" "Distribution_ForAnnotators_Mac/HOW TO USE.md"

echo ""
echo "Done! Zip the 'Distribution_ForAnnotators_Mac' folder (right-click ->"
echo "Compress) and send it to your Mac annotators. They only need to"
echo "double-click DeepfakeAnnotator.app inside it - no Python, no"
echo "installing anything."
echo ""
echo "IMPORTANT: this app is not Apple-notarized (that requires a paid"
echo "Apple Developer account), so macOS will initially block it with a"
echo "security warning. This is expected for a small research tool - see"
echo "'HOW TO USE.md' inside the distribution folder for the one-time fix"
echo "each annotator needs to do (right-click -> Open)."
echo ""
read -p "Press Enter to close..."
