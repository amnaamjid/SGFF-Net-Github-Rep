@echo off
title Build Deepfake Annotator .exe
echo ============================================
echo   Building a standalone .exe
echo   (Run this on native Windows - NOT inside WSL/Linux)
echo ============================================
echo.

echo Installing build requirements (one-time, may take a few minutes)...
python -m pip install -r requirements.txt --quiet
python -m pip install pyinstaller --quiet
if errorlevel 1 (
    echo.
    echo Something went wrong installing requirements.
    echo Make sure you're running this in a normal Windows Command Prompt
    echo ^(not WSL^) and that Python is installed with "Add to PATH" checked.
    pause
    exit /b 1
)

echo.
echo Building DeepfakeAnnotator.exe - this can take several minutes...
echo.
python -m PyInstaller --noconsole --onefile --name DeepfakeAnnotator --collect-all PySide6 app.py

if not exist "dist\DeepfakeAnnotator.exe" (
    echo.
    echo Build failed - DeepfakeAnnotator.exe was not created.
    echo Scroll up for the error message, or send it to the developer.
    pause
    exit /b 1
)

echo.
echo ============================================
echo   Build succeeded!
echo ============================================
echo.
echo Preparing a ready-to-send folder: Distribution_ForAnnotators
if exist "Distribution_ForAnnotators" rmdir /s /q "Distribution_ForAnnotators"
mkdir "Distribution_ForAnnotators"
copy "dist\DeepfakeAnnotator.exe" "Distribution_ForAnnotators\" >nul
mkdir "Distribution_ForAnnotators\Dataset" >nul
mkdir "Distribution_ForAnnotators\results" >nul
mkdir "Distribution_ForAnnotators\progress" >nul
xcopy "Dataset" "Distribution_ForAnnotators\Dataset" /e /i /q >nul
if exist "image_metadata.csv" copy "image_metadata.csv" "Distribution_ForAnnotators\" >nul
copy "ANNOTATOR_GUIDE_NoInstall.md" "Distribution_ForAnnotators\HOW TO USE.md" >nul

echo.
echo Done! Zip the "Distribution_ForAnnotators" folder and send that to
echo your annotators. They only need to double-click DeepfakeAnnotator.exe
echo inside it - no Python, no installing anything.
echo.
pause
