# Admin Quick-Start: Sending This to Your Annotators

This is the short version. (For technical details/tweaking the rules,
see `README.md` instead.)

## Two ways to send this to annotators

**Option A - `.exe` / `.app` (recommended): annotators install nothing at all.**
You build it once, and send the result. Annotators just double-click it.
**Important:** the build has to be done on the same kind of computer it
will run on - build the `.exe` on a Windows machine for your Windows
annotators, and build the `.app` on a Mac for your Mac annotators. If
your annotators use a mix of Windows and Mac, you'll need to build both
(once each) and send each group the right one - they're built from the
exact same code, so there's nothing else to keep in sync.

**Option B - Python folder: annotators install Python once themselves.**
Works identically on Windows, Mac, and Linux with the same folder - no
separate builds needed. Faster for you to send right now. Each
annotator installs Python once and double-clicks a launcher (see
`ANNOTATOR_GUIDE.md`).

Both options produce the exact same app and the exact same
`results/<name>.csv` file at the end - pick whichever is easier for you.

---

## Option A: Building the .exe (Windows) or .app (Mac)

I can't build these for you directly - each one has to be built on the
same kind of computer it will run on, and I only have a Linux
environment here. But it's fully automated for you either way:

### For Windows annotators (build on a Windows machine, not WSL)

1. Copy this whole folder onto your **native Windows** filesystem
   (not inside WSL/Linux) - e.g. `C:\Users\YourName\AnnotationTool`.
   If you built/tested this via WSL before, copying it out of WSL into
   a normal Windows folder is important - PyInstaller run inside WSL
   would build a Linux program, not a Windows `.exe`.
2. Make sure your dataset is already inside `Dataset\` (see below).
3. Double-click **`BUILD_EXE_Windows.bat`** in a normal Windows Command
   Prompt (not WSL). It installs PyInstaller, builds the `.exe`, and
   automatically prepares a ready-to-send folder called
   **`Distribution_ForAnnotators`** containing:
   - `DeepfakeAnnotator.exe`
   - your `Dataset` folder
   - empty `results` / `progress` folders
   - `HOW TO USE.md` (the simple, no-install annotator guide)
4. Zip that `Distribution_ForAnnotators` folder and send it to your
   Windows annotators.

### For Mac annotators (build on a Mac)

1. Copy this whole folder onto the Mac you're building from.
2. Make sure your dataset is already inside `Dataset/` (see below).
3. Double-click **`BUILD_APP_Mac.command`**. (First time only: if
   double-clicking just opens it in a text editor instead of running
   it, right-click → Open With → Terminal instead.) It installs
   PyInstaller, builds the app, and automatically prepares a
   ready-to-send folder called **`Distribution_ForAnnotators_Mac`**
   containing:
   - `DeepfakeAnnotator.app`
   - your `Dataset` folder
   - empty `results` / `progress` folders
   - `HOW TO USE.md` (the simple, no-install annotator guide, which
     covers the one-time "unverified developer" security click-through
     Mac annotators will need to do)
4. Zip that `Distribution_ForAnnotators_Mac` folder (right-click →
   Compress) and send it to your Mac annotators.

Either build only needs to be done once per platform (or again if you
change the dataset or the code). Building takes a few minutes; the
result is several hundred MB (Qt is bundled inside it) - that's normal.

---

## Option B: Sending the Python version directly

### Before you send anything: add your dataset

1. Open this folder.
2. Copy your actual dataset folders (`ID0001_...`, `ID0002_...`, etc.)
   into the `Dataset` folder here, so it looks like:
   ```
   Dataset/
   ├── ID0001_Tom_Cruise/
   │   ├── Real/
   │   └── Fake/
   ├── ID0002_Emma_Watson/
   │   ├── Real/
   │   └── Fake/
   ...
   ```
3. (Optional) If you have `candidate_urls` and `download_log` sheets,
   copy them in too as `candidate_urls.csv` and `download_log.csv`, then
   run `python metadata_builder.py` once (see `README.md` section 3).
   This makes source links show up for annotators.

### Package it up

Zip the **whole folder** (with your dataset now inside it) and send that
one zip to each annotator - by email, Google Drive, WeTransfer, USB,
whatever's easiest. All three annotators can get the exact same zip.

**Do not** send them the `results/` or `progress/` folders from a
previous run - each annotator should start with those folders empty, so
delete anything in there before zipping if you've tested it yourself.

### What to tell each annotator

Just tell them two things:
1. "Unzip this and open **`ANNOTATOR_GUIDE.md`** - it explains everything."
2. **Give each annotator a different name to type in** (e.g. one is
   `Annotator1`, one is `Annotator2`, one is `Annotator3`). This matters -
   if two people use the same name, they'll overwrite each other's work.

That's the entire instruction they need - `ANNOTATOR_GUIDE.md` (included
in the zip) walks them through installing Python, running the app, and
sending their results back to you.

---

## Collecting results back (same for both options)

Each annotator will eventually send you **one file**:
`results/<TheirName>.csv` (e.g. `Annotator1.csv`).

1. Create a `results` folder somewhere on your own computer (e.g. inside
   a fresh copy of this tool, or anywhere convenient).
2. Put all three annotators' CSV files in there together.
3. Open a terminal in that folder and run:
   ```bash
   python majority_vote.py --results-dir results --output final_annotations.csv
   ```
   (or just `python majority_vote.py` if the files are in this project's
   own `results/` folder)
4. `final_annotations.csv` is your combined, final result - one row per
   image, with `FinalDecision` = KEEP / DISCARD / TIE (TIE means the
   annotators disagreed and it needs a manual look).

## They don't have to finish all at once

Annotators can close the app and reopen it any time - it picks up
exactly where they left off, even mid-image. You can ask them to send
you their CSV at any point (even partway through) if you want to check
progress; re-running `majority_vote.py` later with an updated file just
recalculates the result.
