"""
csv_manager.py
Handles all reading/writing of an annotator's results CSV.

Design goals:
- Every image's answers are written to disk the moment they are recorded
  (so a crash / power loss never loses more than the image in progress).
- The "Selected" column (final best-3 choice) is filled in slightly later,
  once all images of a type are scored, so we UPDATE existing rows rather
  than re-appending them.
"""

import os
import csv
import pandas as pd
import config


def csv_path_for(annotator_name):
    safe_name = "".join(c for c in annotator_name.strip() if c.isalnum() or c in ("_", "-")) or "Annotator"
    return os.path.join(config.RESULTS_DIR, f"{safe_name}.csv")


def ensure_csv_exists(path):
    if not os.path.exists(path):
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=config.CSV_COLUMNS)
            writer.writeheader()


def upsert_row(path, row_dict):
    """
    Writes one image's row. If a row already exists for this
    (ID, Type, Image), it is UPDATED in place (so editing an answer after
    going back never creates a duplicate row). Otherwise the row is added.
    """
    ensure_csv_exists(path)
    df = load_dataframe(path)
    full_row = {col: str(row_dict.get(col, "")) for col in config.CSV_COLUMNS}

    if df.empty:
        df = pd.DataFrame([full_row], columns=config.CSV_COLUMNS)
    else:
        match = (
            (df["ID"] == full_row["ID"]) &
            (df["Type"] == full_row["Type"]) &
            (df["Image"] == full_row["Image"])
        )
        if match.any():
            idx = df[match].index[0]
            for col in config.CSV_COLUMNS:
                df.at[idx, col] = full_row[col]
        else:
            df = pd.concat([df, pd.DataFrame([full_row], columns=config.CSV_COLUMNS)], ignore_index=True)

    tmp_path = path + ".tmp"
    df.to_csv(tmp_path, index=False, columns=config.CSV_COLUMNS)
    os.replace(tmp_path, path)


def get_identity_rows_by_type(path, identity_id):
    """
    Returns {"Real": {filename: row_dict, ...}, "Fake": {filename: row_dict, ...}}
    for whatever has already been saved for this identity - used to resume
    mid-identity instead of only mid-dataset.
    """
    df = load_dataframe(path)
    result = {"Real": {}, "Fake": {}}
    if df.empty:
        return result
    subset = df[df["ID"] == str(identity_id)]
    for _, row in subset.iterrows():
        row_dict = row.to_dict()
        img_type = row_dict.get("Type", "")
        if img_type in result:
            result[img_type][row_dict.get("Image", "")] = row_dict
    return result


def append_row(path, row_dict):
    """Append a single completed image's row immediately."""
    ensure_csv_exists(path)
    full_row = {col: row_dict.get(col, "") for col in config.CSV_COLUMNS}
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=config.CSV_COLUMNS)
        writer.writerow(full_row)


def load_dataframe(path):
    ensure_csv_exists(path)
    try:
        return pd.read_csv(path, dtype=str).fillna("")
    except pd.errors.EmptyDataError:
        return pd.DataFrame(columns=config.CSV_COLUMNS)


def update_selected(path, identity_id, image_type, selected_filenames):
    """
    Marks Selected=Yes for the given image filenames (belonging to
    identity_id + image_type) and Selected=No for every other row of
    that identity/type. Rewrites the file safely (temp file + replace).
    """
    df = load_dataframe(path)
    if df.empty:
        return

    mask = (df["ID"] == str(identity_id)) & (df["Type"] == image_type)
    selected_set = set(selected_filenames)

    df.loc[mask, "Selected"] = df.loc[mask, "Image"].apply(
        lambda img: "Yes" if img in selected_set else "No"
    )

    tmp_path = path + ".tmp"
    df.to_csv(tmp_path, index=False, columns=config.CSV_COLUMNS)
    os.replace(tmp_path, path)


def rows_for_identity(path, identity_id):
    df = load_dataframe(path)
    if df.empty:
        return df
    return df[df["ID"] == str(identity_id)]


def remove_identity_rows(path, identity_id):
    """Used when resuming: wipe any partial rows for an unfinished identity
    so it can be safely redone from scratch without duplicate entries."""
    df = load_dataframe(path)
    if df.empty:
        return
    df = df[df["ID"] != str(identity_id)]
    tmp_path = path + ".tmp"
    df.to_csv(tmp_path, index=False, columns=config.CSV_COLUMNS)
    os.replace(tmp_path, path)
