"""
metadata_builder.py
Links every downloaded image file back to where it came from, by joining
your three pipeline sheets:

  candidate_urls   (search results: Title, Source_Page_URL, Trust_Tier, ...)
  download_log     (which candidate got saved as which local filename)
  search_queries   (optional - only used to fill in gaps, not required)

Produces: image_metadata.csv, with ONE row per downloaded image, containing
its source page URL, domain, title, and trust tier. The annotation GUI
(app.py) reads this file automatically and displays it next to each image.

HOW TO USE
----------
1. Put your three sheets in this same folder (DeepfakeAnnotationTool/),
   named exactly:
       candidate_urls.csv    (or .tsv or .xlsx)
       download_log.csv      (or .tsv or .xlsx)
       search_queries.csv    (or .tsv or .xlsx)   [optional]
2. Run:
       python metadata_builder.py
3. It creates image_metadata.csv in this folder. That's it - now run
   app.py as usual and the source info will show automatically.
"""

import os
import sys
import pandas as pd
import config


def find_sheet(basename):
    """Looks for <basename>.csv / .tsv / .xlsx / .xls in BASE_DIR."""
    for ext in (".csv", ".tsv", ".xlsx", ".xls"):
        path = os.path.join(config.BASE_DIR, basename + ext)
        if os.path.exists(path):
            return path
    return None


def load_sheet(basename, required=True):
    path = find_sheet(basename)
    if path is None:
        if required:
            print(f"ERROR: could not find '{basename}.csv' (or .tsv/.xlsx) in:\n  {config.BASE_DIR}")
            print(f"Please put your '{basename}' sheet in that folder and try again.")
            sys.exit(1)
        return None

    print(f"Loading {path} ...")
    if path.lower().endswith((".xlsx", ".xls")):
        df = pd.read_excel(path, dtype=str)
    else:
        # Auto-detect tab vs comma delimiter
        df = pd.read_csv(path, dtype=str, sep=None, engine="python")
    return df.fillna("")


def main():
    candidates_df = load_sheet(config.CANDIDATE_URLS_BASENAME, required=True)
    log_df = load_sheet(config.DOWNLOAD_LOG_BASENAME, required=True)
    load_sheet(config.SEARCH_QUERIES_BASENAME, required=False)  # not needed for matching, just checked for completeness

    required_candidate_cols = {"Query_ID", "Rank"}
    missing = required_candidate_cols - set(candidates_df.columns)
    if missing:
        print(f"ERROR: candidate_urls sheet is missing columns: {missing}")
        sys.exit(1)

    required_log_cols = {"Query_ID", "Identity_ID", "Image_Type", "Saved_Paths", "Used_Ranks"}
    missing = required_log_cols - set(log_df.columns)
    if missing:
        print(f"ERROR: download_log sheet is missing columns: {missing}")
        sys.exit(1)

    # Build a fast lookup: (Query_ID, Rank) -> candidate row
    candidates_df = candidates_df[candidates_df["Rank"].astype(str).str.strip() != ""]
    lookup = {}
    for _, row in candidates_df.iterrows():
        try:
            rank = int(float(row["Rank"]))
        except (ValueError, TypeError):
            continue
        lookup[(row["Query_ID"], rank)] = row

    records = []
    skipped_no_match = 0

    for _, row in log_df.iterrows():
        saved_paths_raw = str(row.get("Saved_Paths", "")).strip()
        used_ranks_raw = str(row.get("Used_Ranks", "")).strip()
        if not saved_paths_raw or not used_ranks_raw:
            continue  # e.g. skipped_unpaired rows with nothing downloaded

        paths = [p.strip() for p in saved_paths_raw.split("|") if p.strip()]
        ranks = [r.strip() for r in used_ranks_raw.split("|") if r.strip()]

        if len(paths) != len(ranks):
            print(f"WARNING: {row.get('Query_ID')} has mismatched Saved_Paths/Used_Ranks counts, skipping this row.")
            continue

        for path, rank_str in zip(paths, ranks):
            try:
                rank = int(float(rank_str))
            except ValueError:
                continue

            cand = lookup.get((row["Query_ID"], rank))
            filename = os.path.basename(path)

            record = {
                "ID": row["Identity_ID"],
                "Type": row["Image_Type"],
                "Image": filename,
                "FullPath": path,
                "Query_ID": row["Query_ID"],
            }
            if cand is not None:
                record.update({
                    "Search_Query": cand.get("Search_Query", ""),
                    "Title": cand.get("Title", ""),
                    "Source_Page_URL": cand.get("Source_Page_URL", ""),
                    "Display_Link": cand.get("Display_Link", ""),
                    "Image_URL": cand.get("Image_URL", ""),
                    "Trust_Tier": cand.get("Trust_Tier", ""),
                    "Score": cand.get("Score", ""),
                })
            else:
                skipped_no_match += 1
                record.update({
                    "Search_Query": "", "Title": "", "Source_Page_URL": "",
                    "Display_Link": "", "Image_URL": "", "Trust_Tier": "", "Score": "",
                })

            records.append(record)

    if not records:
        print("No matching rows found - nothing to write. Check that your sheets share Query_ID/Rank values.")
        sys.exit(1)

    out_df = pd.DataFrame(records, columns=[
        "ID", "Type", "Image", "FullPath", "Query_ID", "Search_Query",
        "Title", "Source_Page_URL", "Display_Link", "Image_URL", "Trust_Tier", "Score",
    ])
    out_df.to_csv(config.METADATA_FILE, index=False)

    print(f"\nDone. Wrote {len(out_df)} image records to:\n  {config.METADATA_FILE}")
    if skipped_no_match:
        print(f"Note: {skipped_no_match} image(s) had no matching candidate_urls row "
              f"(source info will show as blank for those in the annotation tool).")


if __name__ == "__main__":
    main()
