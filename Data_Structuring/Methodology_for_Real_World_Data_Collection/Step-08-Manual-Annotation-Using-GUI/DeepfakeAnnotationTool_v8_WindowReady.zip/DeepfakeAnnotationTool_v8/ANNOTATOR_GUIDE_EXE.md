# How to Use the Annotation Tool

Thank you for helping with this project! This version needs **no
installation at all** - just double-click and go.

## Step 1: Unzip the folder

You should have received a file like `Distribution_ForAnnotators.zip`.
Right-click it → "Extract All" → choose a location you'll remember
(like your Desktop) → Extract.

## Step 2: Start the app

Open the folder and double-click **`DeepfakeAnnotator.exe`**.

- It may take a few seconds to open the first time - that's normal.
- Windows might show a blue "Windows protected your PC" warning the
  first time, because the app isn't digitally signed. This is expected
  for a small research tool like this one. Click **"More info"**, then
  **"Run anyway"**.

## Step 3: Enter your name

Type the **exact name the admin gave you** (for example `Annotator1`).
Use this **exact same name every single time** you open the app - this
is how it remembers your progress and lets you continue where you
left off.

Click **Start / Resume**.

## Step 4: Read the introduction screen

Before annotation begins, you'll see a short screen explaining the
dataset and the annotation rules. Give it a quick read, then click
**"I Understand — Start Annotating"**. You'll see a short version of
these same rules again on the annotation screen itself, so you don't
need to memorize anything.

## Step 5: Annotate

For each image you'll see:

- **The image** in the middle, with zoom buttons below it.
- A **Reference Photo** on the right - a known real photo of the same
  person, so you can compare faces. Use the ← / → arrows if there's
  more than one.
- **Image Source** info (if available) - where the image came from, with
  a link you can click to check it, and a "Copy Link" button as backup.
- **Search buttons** (Images / Wikipedia / Web) if you want to look the
  person up yourself.
- **Questions** to answer with Yes/No.
- For fake images, an optional box to explain what looked artificial.

**Buttons at the bottom:**
- **← Back** - go back and review or change your answer on the previous
  image, any time.
- **Next Image →** - saves your answer and moves on. This button is
  greyed out until you've answered every question.

After you finish all the images for one person, you'll be asked to
click on your best photos (up to 3 - a green checkmark shows what's
selected). **You are not required to select anything** - if none of
the images seem right, you can click Confirm with none selected. If you
try to continue without picking any and some were available, you'll
just get a friendly reminder asking if you're sure - either click
"Continue Anyway" or "Go Back / Review" to change your mind. Nothing is
ever forced.

## Step 6: Taking breaks

**You can close the app at any time** - just close the window normally.
Nothing is lost. When you reopen it and type your name again, you'll
continue from exactly where you stopped.

## Step 7: When you're done (or asked to send progress)

Your answers are saved automatically, and there's just **one file** you
need to send back:

1. Open the folder with `DeepfakeAnnotator.exe` in it.
2. Open the `results` folder inside it.
3. You'll find a file named after you, for example: **`Annotator1.csv`**
4. Send **just that one file** to the admin (email, shared drive,
   WhatsApp, however they asked for it).

That's it - thank you again for your work!
