"""
config.py
Central configuration for the Deepfake Annotation Tool.
Edit the paths below if your folder layout differs.
"""

import os

# ---------------------------------------------------------------------------
# Paths (all relative to this file, so the app works from any location)
# ---------------------------------------------------------------------------
import sys

# When bundled into a standalone .exe with PyInstaller, __file__ points
# inside a temporary extraction folder that's wiped after every run - so
# Dataset/results/progress must instead be found next to the actual .exe,
# or annotators' work would vanish (or never be found) between runs.
if getattr(sys, "frozen", False):
    BASE_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DATASET_DIR = os.path.join(BASE_DIR, "Dataset")
RESULTS_DIR = os.path.join(BASE_DIR, "results")
PROGRESS_DIR = os.path.join(BASE_DIR, "progress")

os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(PROGRESS_DIR, exist_ok=True)

REAL_FOLDER_NAME = "Real"
FAKE_FOLDER_NAME = "Fake"

VALID_IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".bmp", ".webp")

# ---------------------------------------------------------------------------
# Source-metadata sheets (your own search/download pipeline output)
# ---------------------------------------------------------------------------
# Place your exported sheets in BASE_DIR using these names (any of
# .csv / .tsv / .xlsx is fine - metadata_builder.py will find them):
#   search_queries.csv      (optional, not required for matching)
#   candidate_urls.csv      (search results: Title, Source_Page_URL, Trust_Tier, ...)
#   download_log.csv        (which candidate got saved as which local file)
SEARCH_QUERIES_BASENAME = "search_queries"
CANDIDATE_URLS_BASENAME = "candidate_urls"
DOWNLOAD_LOG_BASENAME = "download_log"

# Output produced by metadata_builder.py, consumed by the annotation GUI
METADATA_FILE = os.path.join(BASE_DIR, "image_metadata.csv")

# ---------------------------------------------------------------------------
# Annotation questions
# ---------------------------------------------------------------------------
# Each entry: (field_name_in_csv, question_text_shown_to_annotator)

REAL_QUESTIONS = [
    ("Identity", "Identity matches target?"),
    ("Reliable", "Reliable source?"),
    ("SingleFace", "Single clear face?"),
    ("Quality", "Good quality?"),
]

FAKE_QUESTIONS = [
    ("Identity", "Identity matches target?"),
    ("SingleFace", "Single clear face?"),
    ("Quality", "Good quality?"),
]

# Recorded for analysis only - does NOT affect the keep/discard score
FAKE_EXTRA_QUESTION = ("Artifact", "Obvious AI artifacts?")

# ---------------------------------------------------------------------------
# Scoring rules
# ---------------------------------------------------------------------------
# A real image only meets the "genuine" criteria if every scored question
# is answered "Yes". A fake image only meets the "fake" criteria if the
# first three scored questions are answered "Yes".
#
# NOTE: this KEEP/DISCARD judgment is used ONLY internally, to decide which
# images are offered on the "choose your best photos" screen. It is
# intentionally NOT saved to the results CSV - only the annotator's raw
# Yes/No answers and their final Selected choices are saved. Final
# accept/reject decisions are made later by the admin, after combining all
# annotators' files (see majority_vote.py).
REAL_KEEP_SCORE = len(REAL_QUESTIONS)     # 4
FAKE_KEEP_SCORE = len(FAKE_QUESTIONS)     # 3


def meets_criteria(image_type, answers):
    """Internal-only helper: does this image meet the auto-criteria to be
    offered on the selection screen? Recomputed from the raw answers every
    time (never stored), so it works identically for a freshly-answered
    image and for one restored from a previous session."""
    if image_type == "Real":
        needed, fields = REAL_KEEP_SCORE, [f for f, _ in REAL_QUESTIONS]
    else:
        needed, fields = FAKE_KEEP_SCORE, [f for f, _ in FAKE_QUESTIONS]
    score = sum(1 for f in fields if answers.get(f) == "Yes")
    return score >= needed


MAX_KEEP_PER_TYPE = 3   # maximum images an annotator can pick per identity, per type
# There is intentionally no required MINIMUM anymore - annotators are free
# to select zero images for an identity/type (e.g. if none seemed genuine).
# A gentle, non-blocking reminder is shown instead; see selection_view.py.

# ---------------------------------------------------------------------------
# Reproducible randomisation of identity order
# ---------------------------------------------------------------------------
# Each annotator sees identities in a different, but reproducible, order.
# The seed is derived from the annotator's name so re-running the app
# with the same name always regenerates the same order.
def seed_for_annotator(name: str) -> int:
    return sum(ord(c) for c in name.strip().lower()) + len(name.strip())


# ---------------------------------------------------------------------------
# CSV columns (order matters - this is the schema written to disk)
# ---------------------------------------------------------------------------
# Deliberately does NOT include a computed Keep/Discard decision or score -
# only the annotator's raw answers and their final Selected choices are
# recorded. Final aggregation happens later from these raw answers.
CSV_COLUMNS = [
    "ID",
    "Celebrity",
    "Image",
    "Type",           # Real / Fake
    "Identity",
    "Reliable",       # Real only, blank for Fake
    "SingleFace",
    "Quality",
    "Artifact",        # Fake only, blank for Real
    "Artifact_Explanation",  # Fake only - free-text evidence/reasoning
    "Selected",        # Yes / No / blank - the annotator's final choice
    "AnnotationStart",
    "AnnotationEnd",
]
