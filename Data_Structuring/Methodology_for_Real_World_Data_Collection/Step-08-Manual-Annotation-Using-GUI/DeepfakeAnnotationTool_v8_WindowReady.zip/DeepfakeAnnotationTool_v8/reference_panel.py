"""
reference_panel.py
A single, fixed-position reference photo of the identity's real appearance,
always visible while annotating any image (real or fake) of that identity.
It never disappears between images. If more than one real photo exists,
Prev/Next lets the annotator cycle through them for comparison.
"""

import os
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton
from PySide6.QtGui import QPixmap
from PySide6.QtCore import Qt

PHOTO_SIZE = 220


class ReferencePanel(QWidget):
    def __init__(self):
        super().__init__()
        self._filtered_paths = []
        self._index = 0

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        title = QLabel("Reference Photo (known real image)")
        title.setStyleSheet("font-weight: bold; font-size: 12px; color: #444;")
        layout.addWidget(title)

        self.photo_label = QLabel()
        self.photo_label.setFixedSize(PHOTO_SIZE, PHOTO_SIZE)
        self.photo_label.setAlignment(Qt.AlignCenter)
        self.photo_label.setWordWrap(True)
        self.photo_label.setStyleSheet(
            "border: 2px solid #888; border-radius: 6px; background: #fafafa;"
        )
        layout.addWidget(self.photo_label, alignment=Qt.AlignHCenter)

        nav_row = QHBoxLayout()
        self.prev_button = QPushButton("\u2190")
        self.prev_button.setFixedWidth(36)
        self.prev_button.clicked.connect(self._prev)

        self.counter_label = QLabel("")
        self.counter_label.setAlignment(Qt.AlignCenter)
        self.counter_label.setWordWrap(True)
        self.counter_label.setStyleSheet("font-size: 10px; color: #666;")

        self.next_button = QPushButton("\u2192")
        self.next_button.setFixedWidth(36)
        self.next_button.clicked.connect(self._next)

        nav_row.addWidget(self.prev_button)
        nav_row.addWidget(self.counter_label, stretch=1)
        nav_row.addWidget(self.next_button)
        layout.addLayout(nav_row)

    def load(self, image_paths, exclude_path=None):
        """Call this every time the annotated image changes. Keeps the
        current reference photo/index stable across images where possible,
        instead of always resetting to photo #1."""
        new_filtered = [p for p in image_paths if p != exclude_path]

        if self._filtered_paths and 0 <= self._index < len(self._filtered_paths):
            current_path = self._filtered_paths[self._index]
            if current_path in new_filtered:
                self._index = new_filtered.index(current_path)
            else:
                self._index = 0
        else:
            self._index = 0

        self._filtered_paths = new_filtered
        self._render()

    def _render(self):
        if not self._filtered_paths:
            self.photo_label.setText("No reference photo\navailable for this identity")
            self.counter_label.setText("")
            self.prev_button.setEnabled(False)
            self.next_button.setEnabled(False)
            return

        path = self._filtered_paths[self._index]
        pix = QPixmap(path)
        if not pix.isNull():
            pix = pix.scaled(
                PHOTO_SIZE - 8, PHOTO_SIZE - 8, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            self.photo_label.setPixmap(pix)
        else:
            self.photo_label.setText("(preview unavailable)")

        self.counter_label.setText(
            f"{self._index + 1} / {len(self._filtered_paths)} \u2014 {os.path.basename(path)}"
        )
        multiple = len(self._filtered_paths) > 1
        self.prev_button.setEnabled(multiple)
        self.next_button.setEnabled(multiple)

    def _prev(self):
        if self._filtered_paths:
            self._index = (self._index - 1) % len(self._filtered_paths)
            self._render()

    def _next(self):
        if self._filtered_paths:
            self._index = (self._index + 1) % len(self._filtered_paths)
            self._render()
