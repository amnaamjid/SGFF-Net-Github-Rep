"""
link_opener.py
Best-effort URL opening that actually works under WSL.

Why this exists: under WSL (Windows Subsystem for Linux), there is no
Linux browser registered, so both Qt's QDesktopServices.openUrl() and
Python's webbrowser.open() fail silently ("Unable to detect a web
browser to launch..."). The fix is to hand the URL off to Windows itself
(via powershell.exe / cmd.exe, which WSL can call directly), so it opens
in the user's normal Windows browser.
"""

import subprocess
import webbrowser


def is_wsl():
    try:
        with open("/proc/version", "r") as f:
            return "microsoft" in f.read().lower()
    except Exception:
        return False


def open_url(url):
    """Best-effort URL opening. Returns True if a launch attempt was made
    that's likely to have worked, False if every strategy failed."""
    if not url:
        return False

    if is_wsl():
        # Hand off to Windows so it opens in the user's actual Windows browser.
        for cmd in (
            ["powershell.exe", "-NoProfile", "-Command", f'Start-Process "{url}"'],
            ["cmd.exe", "/c", "start", "", url],
            ["explorer.exe", url],
        ):
            try:
                subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return True
            except Exception:
                continue

    # Regular Linux desktop / macOS / Windows-native Python
    try:
        if webbrowser.open(url):
            return True
    except Exception:
        pass

    try:
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtCore import QUrl
        if QDesktopServices.openUrl(QUrl(url)):
            return True
    except Exception:
        pass

    try:
        subprocess.Popen(["xdg-open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        pass

    return False
