"""
gui.py
Main application window.

v4 additions on top of v3 (based on the detailed requirements doc):
- A single, fixed Reference Photo panel (with Prev/Next) that never
  disappears while annotating any image of that identity.
- Click-to-select thumbnails with a live "Selected: X / N" counter on the
  best-N screen (instead of checkboxes).
- A free-text "Explanation / Evidence" field for the manipulation-artifact
  question on Fake images, saved to CSV.
- "Review Completed Identities" - lets an annotator jump back into ANY
  identity they've already finished, review or change answers, and return
  to exactly where they were.
- Explicit "Save & Exit" buttons (on top of the fact that everything
  autosaves and closing the window is always safe).
- An overall dataset-wide progress indicator ("Image 37 of 200"), not just
  per-identity.
- Multiple one-click search shortcuts (Images / Wikipedia / General) for
  identity verification.

Still true from v3, deliberately unchanged:
- NOTHING is a popup / modal dialog. The "select N images" validation
  message is an inline warning banner, not a popup - that is what makes it
  impossible to lose, minimize away, or have it block the app. A real
  modal here would reintroduce the exact bug this was built to fix.
"""

import os
from datetime import datetime
from urllib.parse import quote

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QStackedWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QLineEdit, QPushButton, QRadioButton, QButtonGroup, QProgressBar,
    QGroupBox, QApplication, QPlainTextEdit, QScrollArea, QFrame
)
from PySide6.QtCore import Qt

import config
import dataset_loader
import csv_manager
import progress_manager
import metadata_loader
import link_opener
from image_viewer import ImageViewer
from selection_view import SelectionView
from reference_panel import ReferencePanel


ARTIFACT_EXAMPLES = (
    "e.g. unnatural facial features, distorted eyes, inconsistent lighting, "
    "strange skin texture, hair artifacts, incorrect shadows, anatomical "
    "inconsistencies, blending errors, background distortions, unusual edges..."
)


# ---------------------------------------------------------------------------
# Welcome page
# ---------------------------------------------------------------------------
class WelcomePage(QWidget):
    def __init__(self, on_start, on_exit):
        super().__init__()
        self.on_start = on_start

        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)

        title = QLabel("Deepfake Dataset Annotation Tool")
        title.setStyleSheet("font-size: 22px; font-weight: bold;")
        title.setAlignment(Qt.AlignCenter)

        subtitle = QLabel(
            "Enter your annotator name to begin.\n"
            "If you've worked on this before, use the SAME name to resume\n"
            "exactly where you left off - even mid-identity."
        )
        subtitle.setAlignment(Qt.AlignCenter)

        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("e.g. Annotator1")
        self.name_input.setFixedWidth(280)
        self.name_input.returnPressed.connect(self._start)

        self.start_button = QPushButton("Start / Resume")
        self.start_button.setFixedWidth(280)
        self.start_button.clicked.connect(self._start)

        exit_button = QPushButton("Exit")
        exit_button.setFixedWidth(280)
        exit_button.clicked.connect(on_exit)

        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet("color: #b00;")

        layout.addWidget(title)
        layout.addSpacing(10)
        layout.addWidget(subtitle)
        layout.addSpacing(20)
        layout.addWidget(self.name_input, alignment=Qt.AlignCenter)
        layout.addSpacing(10)
        layout.addWidget(self.start_button, alignment=Qt.AlignCenter)
        layout.addSpacing(6)
        layout.addWidget(exit_button, alignment=Qt.AlignCenter)
        layout.addWidget(self.status_label)

    def _start(self):
        name = self.name_input.text().strip()
        if not name:
            self.status_label.setText("Please enter your name.")
            return
        self.status_label.setText("")
        self.on_start(name)

    def set_error(self, message):
        self.status_label.setText(message)


# ---------------------------------------------------------------------------
# Introduction page - shown after entering a name, before annotation begins
# ---------------------------------------------------------------------------
INTRO_RULES_TEXT = (
    "<b>Annotation Rules</b><br>"
    "<b>Real images:</b> only treat an image as a genuine real image if "
    "<b>ALL</b> questions for that image are answered <b>Yes</b>.<br>"
    "<b>Fake images:</b> only treat an image as a fake image if the "
    "<b>FIRST THREE</b> questions for that image are answered <b>Yes</b>."
)


class IntroductionPage(QWidget):
    def __init__(self, on_begin):
        super().__init__()
        self._on_begin = on_begin

        outer = QVBoxLayout(self)

        title = QLabel("Before You Begin")
        title.setStyleSheet("font-size: 22px; font-weight: bold;")
        title.setAlignment(Qt.AlignCenter)
        outer.addWidget(title)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)

        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setAlignment(Qt.AlignTop)

        self.body_label = QLabel("")
        self.body_label.setWordWrap(True)
        self.body_label.setTextFormat(Qt.RichText)
        self.body_label.setStyleSheet("font-size: 13px; line-height: 150%;")
        content_layout.addWidget(self.body_label)

        rules_box = QFrame()
        rules_box.setStyleSheet(
            "background: #eef4ff; border: 1px solid #9db8e8; border-radius: 6px; padding: 10px;"
        )
        rules_layout = QVBoxLayout(rules_box)
        rules_label = QLabel(INTRO_RULES_TEXT)
        rules_label.setWordWrap(True)
        rules_layout.addWidget(rules_label)
        content_layout.addWidget(rules_box)

        scroll.setWidget(content)
        outer.addWidget(scroll, stretch=1)

        begin_button = QPushButton("I Understand \u2014 Start Annotating")
        begin_button.setFixedWidth(280)
        begin_button.clicked.connect(self._on_begin)
        outer.addWidget(begin_button, alignment=Qt.AlignCenter)

    def set_identity_count(self, total_identities):
        self.body_label.setText(
            f"""
            <p>This dataset contains images of <b>{total_identities} unique identities</b>.
            These identities include actors, actresses, cricketers, politicians, business
            leaders, scientists, social media content creators, athletes, and other public
            figures.</p>

            <p>Each identity has one or more <b>real</b> images and one or more corresponding
            <b>fake</b> images.</p>

            <p>The <b>real</b> images were collected by searching for the person's name on
            the internet.</p>

            <p>The <b>fake</b> images are AI-generated or deepfake images collected from the
            internet using searches such as the person's name together with keywords like
            "AI generated," "deepfake," "AI image," or "viral deepfake."</p>

            <p>The number of images is different for each identity. For example:</p>
            <ul>
              <li>Some identities have 1 real and 1 fake image.</li>
              <li>Some have 2 real and 2 fake images.</li>
              <li>Some have 4 real and 2 fake images.</li>
              <li>Some have 1 real and 5 fake images.</li>
              <li>Other combinations are also possible.</li>
            </ul>

            <p>Your task is to answer the provided questions carefully for each image, and
            identify genuine images according to the annotation rules below.</p>
            """
        )


# ---------------------------------------------------------------------------
# Finished page
# ---------------------------------------------------------------------------
class FinishedPage(QWidget):
    def __init__(self, on_back_to_welcome):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)

        self.title_label = QLabel("")
        self.title_label.setStyleSheet("font-size: 20px; font-weight: bold;")
        self.title_label.setAlignment(Qt.AlignCenter)

        self.detail_label = QLabel("")
        self.detail_label.setAlignment(Qt.AlignCenter)
        self.detail_label.setWordWrap(True)

        back_button = QPushButton("Back to start screen")
        back_button.setFixedWidth(220)
        back_button.clicked.connect(on_back_to_welcome)

        layout.addWidget(self.title_label)
        layout.addSpacing(10)
        layout.addWidget(self.detail_label)
        layout.addSpacing(20)
        layout.addWidget(back_button, alignment=Qt.AlignCenter)

    def set_message(self, title, detail):
        self.title_label.setText(title)
        self.detail_label.setText(detail)


# ---------------------------------------------------------------------------
# Browse page: lets the annotator jump back into any COMPLETED identity
# ---------------------------------------------------------------------------
class BrowsePage(QWidget):
    def __init__(self, on_select, on_cancel):
        super().__init__()
        self.on_select = on_select

        layout = QVBoxLayout(self)

        header = QHBoxLayout()
        title = QLabel("Review a Completed Identity")
        title.setStyleSheet("font-size: 16px; font-weight: bold;")
        cancel_button = QPushButton("\u2190 Back to current work")
        cancel_button.clicked.connect(on_cancel)
        header.addWidget(title)
        header.addStretch(1)
        header.addWidget(cancel_button)
        layout.addLayout(header)

        hint = QLabel(
            "Click any completed identity below to review or change your answers. "
            "You'll return to exactly where you were when you finish."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color: #666;")
        layout.addWidget(hint)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.list_holder = QWidget()
        self.list_layout = QVBoxLayout(self.list_holder)
        self.list_layout.setAlignment(Qt.AlignTop)
        scroll.setWidget(self.list_holder)
        layout.addWidget(scroll, stretch=1)

    def populate(self, rows):
        """rows: list of (identity_id, celebrity, status_text, is_completed)"""
        while self.list_layout.count():
            item = self.list_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

        completed_rows = [r for r in rows if r[3]]
        if not completed_rows:
            empty = QLabel("No completed identities yet - finish at least one to review it here.")
            empty.setStyleSheet("color: #888;")
            self.list_layout.addWidget(empty)
            return

        for identity_id, celebrity, status_text, is_completed in completed_rows:
            row_button = QPushButton(f"{identity_id} \u2014 {celebrity}   ({status_text})")
            row_button.setStyleSheet("text-align: left; padding: 8px;")
            row_button.clicked.connect(lambda checked=False, i=identity_id: self.on_select(i))
            self.list_layout.addWidget(row_button)


# ---------------------------------------------------------------------------
# Annotation page
# ---------------------------------------------------------------------------
class AnnotationPage(QWidget):
    def __init__(self, on_primary_clicked, on_back_clicked, on_browse_clicked,
                 on_exit_review_clicked, on_exit_app, on_continue_anyway_selection):
        super().__init__()
        self.question_groups = {}
        self._current_source_url = ""
        self._search_urls = {}

        root = QVBoxLayout(self)

        # --- Review-mode banner (hidden unless browsing a completed identity) ---
        self.review_banner = QFrame()
        self.review_banner.setStyleSheet("background: #fff6dd; border: 1px solid #e0c060; border-radius: 4px;")
        banner_layout = QHBoxLayout(self.review_banner)
        self.review_banner_label = QLabel("")
        self.review_banner_label.setStyleSheet("font-weight: bold;")
        exit_review_button = QPushButton("Exit Review \u2192 Back to my place")
        exit_review_button.clicked.connect(on_exit_review_clicked)
        banner_layout.addWidget(self.review_banner_label)
        banner_layout.addStretch(1)
        banner_layout.addWidget(exit_review_button)
        self.review_banner.setVisible(False)
        root.addWidget(self.review_banner)

        # --- Prominent identity name banner ---
        name_row = QVBoxLayout()
        self.identity_name_label = QLabel("")
        self.identity_name_label.setAlignment(Qt.AlignCenter)
        self.identity_name_label.setStyleSheet(
            "font-size: 26px; font-weight: 800; color: #1a1a2e; padding: 4px 0;"
        )
        self.identity_id_label = QLabel("")
        self.identity_id_label.setAlignment(Qt.AlignCenter)
        self.identity_id_label.setStyleSheet("font-size: 12px; color: #888;")

        name_row.addWidget(self.identity_name_label)
        name_row.addWidget(self.identity_id_label)
        root.addLayout(name_row)

        # --- Header: image type + counter ---
        header = QHBoxLayout()
        self.type_label = QLabel("")
        self.type_label.setStyleSheet("font-size: 14px; font-weight: bold; color: #555;")
        self.counter_label = QLabel("")
        self.counter_label.setStyleSheet("font-size: 14px;")

        header.addStretch(1)
        header.addWidget(self.type_label)
        header.addSpacing(20)
        header.addWidget(self.counter_label)
        header.addStretch(1)
        root.addLayout(header)

        # --- Overall progress + Browse/Exit shortcuts ---
        sub_header = QHBoxLayout()
        self.overall_progress_label = QLabel("")
        self.overall_progress_label.setStyleSheet("font-size: 11px; color: #777;")
        browse_button = QPushButton("Review Completed Identities")
        browse_button.clicked.connect(on_browse_clicked)
        save_exit_button = QPushButton("Save && Exit")
        save_exit_button.clicked.connect(on_exit_app)
        sub_header.addWidget(self.overall_progress_label)
        sub_header.addStretch(1)
        sub_header.addWidget(browse_button)
        sub_header.addWidget(save_exit_button)
        root.addLayout(sub_header)

        # --- Permanent rules reminder (visible in both questions & selection modes) ---
        rules_reminder = QFrame()
        rules_reminder.setStyleSheet(
            "background: #eef4ff; border: 1px solid #c8d8f5; border-radius: 4px;"
        )
        rules_reminder_layout = QHBoxLayout(rules_reminder)
        rules_reminder_layout.setContentsMargins(8, 4, 8, 4)
        rules_reminder_label = QLabel(
            "\U0001F4CB Reminder \u2014 REAL images: only genuine if ALL questions = Yes.  "
            "FAKE images: only fake if the FIRST THREE questions = Yes."
        )
        rules_reminder_label.setWordWrap(True)
        rules_reminder_label.setStyleSheet("font-size: 11px; color: #33415c;")
        rules_reminder_layout.addWidget(rules_reminder_label)
        root.addWidget(rules_reminder)

        # --- Inner stack: questions view <-> selection view ---
        self.inner_stack = QStackedWidget()
        root.addWidget(self.inner_stack, stretch=1)

        self.questions_widget = self._build_questions_widget()
        self.inner_stack.addWidget(self.questions_widget)

        self.selection_view = SelectionView(on_continue_anyway_selection)
        self.inner_stack.addWidget(self.selection_view)

        # --- Footer: Back / Primary action + per-identity progress ---
        footer = QHBoxLayout()
        self.progress_bar = QProgressBar()
        self.progress_bar.setFormat("%p%  (%v / %m identities)")

        self.back_button = QPushButton("\u2190 Back")
        self.back_button.setFixedWidth(120)
        self.back_button.clicked.connect(on_back_clicked)

        self.primary_button = QPushButton("Next Image \u2192")
        self.primary_button.setFixedWidth(180)
        self.primary_button.clicked.connect(on_primary_clicked)

        footer.addWidget(self.progress_bar, stretch=1)
        footer.addWidget(self.back_button)
        footer.addWidget(self.primary_button)
        root.addLayout(footer)

    # -------------------------------------------------------------
    def _build_questions_widget(self):
        widget = QWidget()
        body = QHBoxLayout(widget)

        self.viewer = ImageViewer()
        body.addWidget(self.viewer, stretch=3)

        right_container = QWidget()
        right_column = QVBoxLayout(right_container)

        # --- Source info box ---
        self.source_box = QGroupBox("Image Source")
        source_layout = QVBoxLayout()
        self.source_box.setLayout(source_layout)

        self.source_title_label = QLabel("")
        self.source_title_label.setWordWrap(True)
        self.source_title_label.setStyleSheet("font-weight: bold;")

        self.source_link_label = QLabel("")
        self.source_link_label.setWordWrap(True)
        self.source_link_label.setOpenExternalLinks(True)
        self.source_link_label.setTextFormat(Qt.RichText)
        self.source_link_label.setTextInteractionFlags(Qt.TextBrowserInteraction)

        self.source_domain_label = QLabel("")
        self.source_domain_label.setWordWrap(True)

        self.source_tier_label = QLabel("")
        self.source_tier_label.setWordWrap(True)

        self.source_query_label = QLabel("")
        self.source_query_label.setWordWrap(True)
        self.source_query_label.setStyleSheet("color: #666; font-size: 11px;")

        link_row = QHBoxLayout()
        self.source_copy_button = QPushButton("Copy Link")
        self.source_copy_button.setEnabled(False)
        self.source_copy_button.clicked.connect(self._copy_source_link)
        link_row.addWidget(self.source_copy_button)
        link_row.addStretch(1)

        source_layout.addWidget(self.source_title_label)
        source_layout.addWidget(self.source_link_label)
        source_layout.addWidget(self.source_domain_label)
        source_layout.addWidget(self.source_tier_label)
        source_layout.addWidget(self.source_query_label)
        source_layout.addLayout(link_row)

        self.source_box.setFixedWidth(320)
        right_column.addWidget(self.source_box)

        # --- Reference photo (fixed, always visible) ---
        self.reference_box = QGroupBox("Compare Identity")
        ref_layout = QVBoxLayout()
        self.reference_box.setLayout(ref_layout)

        self.reference_panel = ReferencePanel()
        ref_layout.addWidget(self.reference_panel)

        search_row = QHBoxLayout()
        self.search_images_button = QPushButton("Images")
        self.search_wiki_button = QPushButton("Wikipedia")
        self.search_general_button = QPushButton("Web")
        self.search_images_button.clicked.connect(lambda: self._open_web_search("images"))
        self.search_wiki_button.clicked.connect(lambda: self._open_web_search("wikipedia"))
        self.search_general_button.clicked.connect(lambda: self._open_web_search("general"))
        for b in (self.search_images_button, self.search_wiki_button, self.search_general_button):
            search_row.addWidget(b)
        ref_layout.addLayout(search_row)

        self.search_status_label = QLabel("")
        self.search_status_label.setWordWrap(True)
        self.search_status_label.setStyleSheet("color: #666; font-size: 10px;")
        ref_layout.addWidget(self.search_status_label)

        self.reference_box.setFixedWidth(320)
        right_column.addWidget(self.reference_box)

        # --- Questions ---
        self.question_box = QGroupBox("Questions")
        self.question_layout = QGridLayout()
        self.question_box.setLayout(self.question_layout)
        self.question_box.setFixedWidth(320)
        right_column.addWidget(self.question_box)

        # --- Explanation / evidence (Fake images only) ---
        self.explanation_box = QGroupBox("Explanation / Evidence")
        explanation_layout = QVBoxLayout()
        self.explanation_box.setLayout(explanation_layout)

        hint_label = QLabel(ARTIFACT_EXAMPLES)
        hint_label.setWordWrap(True)
        hint_label.setStyleSheet("color: #777; font-size: 10px;")
        explanation_layout.addWidget(hint_label)

        self.explanation_text = QPlainTextEdit()
        self.explanation_text.setPlaceholderText("Describe what you noticed (optional but encouraged)...")
        self.explanation_text.setFixedHeight(80)
        explanation_layout.addWidget(self.explanation_text)

        self.explanation_box.setFixedWidth(320)
        self.explanation_box.setVisible(False)
        right_column.addWidget(self.explanation_box)

        right_column.addStretch(1)

        right_scroll = QScrollArea()
        right_scroll.setWidgetResizable(True)
        right_scroll.setWidget(right_container)
        right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        right_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        right_scroll.setFrameShape(QFrame.NoFrame)
        right_scroll.setMinimumWidth(340)
        right_scroll.setMaximumWidth(340)
        self.right_scroll = right_scroll

        body.addWidget(right_scroll, stretch=1)
        return widget

    # -------------------------------------------------------------
    # Mode switching
    # -------------------------------------------------------------
    def show_questions_mode(self):
        self.inner_stack.setCurrentWidget(self.questions_widget)

    def show_selection_mode(self):
        self.inner_stack.setCurrentWidget(self.selection_view)

    def set_back_enabled(self, enabled):
        self.back_button.setEnabled(enabled)

    def set_primary_button(self, text, enabled):
        self.primary_button.setText(text)
        self.primary_button.setEnabled(enabled)

    def set_review_banner(self, active, identity_label=""):
        self.review_banner.setVisible(active)
        if active:
            self.review_banner_label.setText(f"Reviewing previously completed identity: {identity_label}")

    # -------------------------------------------------------------
    def set_header(self, identity_id, celebrity, image_type, index, total):
        self.identity_name_label.setText(celebrity)
        self.identity_id_label.setText(identity_id)
        self.type_label.setText(image_type.upper())
        if index < total:
            self.counter_label.setText(f"Image {index + 1} / {total}")
        else:
            self.counter_label.setText(f"Reviewing all {total} images")

    def set_progress(self, done, total):
        self.progress_bar.setMaximum(max(total, 1))
        self.progress_bar.setValue(done)

    def set_overall_progress(self, done_images, total_images):
        self.overall_progress_label.setText(f"Overall progress: image {done_images} of {total_images}")

    def load_image(self, path):
        self.viewer.load_image(path)

    def set_reference_images(self, image_paths, exclude_path=None):
        self.reference_panel.load(image_paths, exclude_path=exclude_path)

    def set_search_context(self, name):
        self._search_urls = {
            "images": f"https://www.google.com/search?q={quote(name)}&tbm=isch",
            "wikipedia": f"https://en.wikipedia.org/wiki/Special:Search?search={quote(name)}",
            "general": f"https://www.google.com/search?q={quote(name)}",
        }
        self.search_status_label.setText("")

    def _open_web_search(self, kind):
        url = self._search_urls.get(kind, "")
        self._try_open_url(url, self.search_status_label)

    def _copy_source_link(self):
        if self._current_source_url:
            QApplication.clipboard().setText(self._current_source_url)
            self.source_query_label.setText("Link copied to clipboard \u2713")

    def _try_open_url(self, url, status_label):
        if not url:
            return
        opened = link_opener.open_url(url)
        if not opened:
            status_label.setText(
                "Couldn't open a browser automatically. Use 'Copy Link' and paste it into your browser."
            )
        else:
            status_label.setText("Opening in your browser...")

    # -------------------------------------------------------------
    def set_source_info(self, info):
        if not info:
            self.source_title_label.setText("No source info available for this image.")
            self.source_link_label.setText("")
            self.source_domain_label.setText("")
            self.source_tier_label.setText("")
            self.source_query_label.setText("")
            self.source_copy_button.setEnabled(False)
            self._current_source_url = ""
            return

        title = info.get("Title", "") or "(no title)"
        domain = info.get("Display_Link", "") or "(unknown domain)"
        tier = info.get("Trust_Tier", "")
        query = info.get("Search_Query", "")
        url = info.get("Source_Page_URL", "")

        self.source_title_label.setText(title)
        if url:
            self.source_link_label.setText(f'<a href="{url}">Open source page</a>')
        else:
            self.source_link_label.setText("(no link available)")
        self.source_domain_label.setText(f"Domain: {domain}")
        self.source_tier_label.setText(f"Trust tier: {tier}" if tier else "Trust tier: (not rated)")
        self.source_query_label.setText(f"Found via search: \u201c{query}\u201d" if query else "")

        self._current_source_url = url
        self.source_copy_button.setEnabled(bool(url))

    # -------------------------------------------------------------
    # Questions
    # -------------------------------------------------------------
    def build_questions(self, question_defs, extra_question=None, show_explanation=False):
        while self.question_layout.count():
            item = self.question_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        self.question_groups = {}

        row = 0
        all_defs = list(question_defs)
        scored_fields = {f for f, _ in question_defs}
        if extra_question:
            all_defs = all_defs + [extra_question]

        for field, text in all_defs:
            label = QLabel(text)
            label.setWordWrap(True)
            yes_btn = QRadioButton("Yes")
            no_btn = QRadioButton("No")
            group = QButtonGroup(self)
            group.addButton(yes_btn)
            group.addButton(no_btn)
            group.buttonToggled.connect(self._on_any_answer_changed)

            self.question_layout.addWidget(label, row, 0, 1, 2)
            row += 1
            self.question_layout.addWidget(yes_btn, row, 0)
            self.question_layout.addWidget(no_btn, row, 1)
            row += 1

            self.question_groups[field] = {
                "group": group, "yes": yes_btn, "no": no_btn, "scored": field in scored_fields
            }

        self.explanation_box.setVisible(show_explanation)
        self.explanation_text.setPlainText("")

    def set_answers(self, answers_dict):
        for field, info in self.question_groups.items():
            value = answers_dict.get(field, "")
            if value == "Yes":
                info["yes"].setChecked(True)
            elif value == "No":
                info["no"].setChecked(True)

    def set_explanation(self, text):
        self.explanation_text.setPlainText(text or "")

    def get_explanation(self):
        return self.explanation_text.toPlainText().strip()

    def _on_any_answer_changed(self, *_):
        self.primary_button.setEnabled(self.all_answered())

    def all_answered(self):
        for info in self.question_groups.values():
            if not info["yes"].isChecked() and not info["no"].isChecked():
                return False
        return True

    def collect_answers(self):
        answers = {}
        score = 0
        for field, info in self.question_groups.items():
            value = "Yes" if info["yes"].isChecked() else "No"
            answers[field] = value
            if info["scored"] and value == "Yes":
                score += 1
        return answers, score


# ---------------------------------------------------------------------------
# Main window / state machine
# ---------------------------------------------------------------------------
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Deepfake Dataset Annotation Tool")
        self.resize(1300, 800)

        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)

        self.welcome_page = WelcomePage(self._on_start, self.close)
        self.intro_page = IntroductionPage(self._begin_annotation)
        self.annotation_page = AnnotationPage(
            self._on_primary_clicked, self._on_back_clicked,
            self._open_browse_page, self._exit_review_mode, self.close,
            self._force_continue_empty_selection
        )
        self.finished_page = FinishedPage(self._back_to_welcome)
        self.browse_page = BrowsePage(self._jump_to_identity, self._close_browse_page)

        self.stack.addWidget(self.welcome_page)
        self.stack.addWidget(self.intro_page)
        self.stack.addWidget(self.annotation_page)
        self.stack.addWidget(self.finished_page)
        self.stack.addWidget(self.browse_page)
        self.stack.setCurrentWidget(self.welcome_page)

        # Session state
        self.annotator_name = None
        self.csv_path = None
        self.identities_all = []   # every identity, in this annotator's order
        self.identities = []       # only the not-yet-completed ones
        self.completed_ids_set = set()
        self.current_identity_pos = -1
        self.current_identity = None
        self.type_order = []
        self.states = {}
        self.current_type = None
        self.current_pos = 0
        self.mode = "questions"
        self.image_start_time = None
        self.total_identities = 0
        self.completed_count = 0
        self.total_images_all = 0
        self.metadata = metadata_loader.load_metadata()

        # Review/browse state
        self.browsing_identity_id = None
        self._pre_browse_identity = None

    # -----------------------------------------------------------------
    def _back_to_welcome(self):
        self.stack.setCurrentWidget(self.welcome_page)

    def _show_finished(self, title, detail):
        self.finished_page.set_message(title, detail)
        self.stack.setCurrentWidget(self.finished_page)

    # -----------------------------------------------------------------
    # Startup / resume
    # -----------------------------------------------------------------
    def _on_start(self, name):
        all_identities = dataset_loader.load_dataset()
        if not all_identities:
            self.welcome_page.set_error(
                f"No identities found in:\n{config.DATASET_DIR}\n"
                "Make sure the Dataset folder exists and follows the expected structure."
            )
            return

        self.annotator_name = name
        self.csv_path = csv_manager.csv_path_for(name)
        csv_manager.ensure_csv_exists(self.csv_path)

        self.identities_all = dataset_loader.order_for_annotator(all_identities, name)
        self.total_identities = len(self.identities_all)
        self.total_images_all = sum(len(i.real_images) + len(i.fake_images) for i in self.identities_all)

        progress = progress_manager.load_progress(name)
        self.completed_ids_set = set(progress["completed_ids"])

        self.identities = [i for i in self.identities_all if i.id not in self.completed_ids_set]
        self.completed_count = len(self.completed_ids_set)

        if not self.identities:
            self._show_finished(
                "All done!",
                f"{name} has already completed all {self.total_identities} identities.\n"
                f"Results are saved in:\n{self.csv_path}"
            )
            return

        self.stack.setCurrentWidget(self.intro_page)
        self.intro_page.set_identity_count(self.total_identities)

    def _begin_annotation(self):
        self.stack.setCurrentWidget(self.annotation_page)
        self.current_identity_pos = -1
        self._advance_to_next_identity()

    # -----------------------------------------------------------------
    # Identity-level navigation
    # -----------------------------------------------------------------
    def _advance_to_next_identity(self):
        self.current_identity_pos += 1
        if self.current_identity_pos >= len(self.identities):
            self._show_finished(
                "Finished!",
                f"All identities completed. Thank you, {self.annotator_name}!\n"
                f"Results saved to:\n{self.csv_path}"
            )
            return

        self.annotation_page.set_progress(self.completed_count, self.total_identities)
        self.current_identity = self.identities[self.current_identity_pos]
        self._load_identity_state(self.current_identity)
        self._resolve_starting_point()

    def _load_identity_state(self, identity):
        existing = csv_manager.get_identity_rows_by_type(self.csv_path, identity.id)

        self.states = {}
        self.type_order = []

        for image_type, images in (("Real", identity.real_images), ("Fake", identity.fake_images)):
            if not images:
                continue
            self.type_order.append(image_type)

            type_states = []
            for path in images:
                fname = os.path.basename(path)
                row = existing.get(image_type, {}).get(fname)
                # "Identity" is asked for every image (Real and Fake alike), so a
                # non-empty value there is our marker that this row was fully
                # answered in a previous session (Score/Decision are no longer
                # stored, so we can't check those anymore).
                if row and str(row.get("Identity", "")).strip() != "":
                    answers = {
                        "Identity": row.get("Identity", ""),
                        "Reliable": row.get("Reliable", ""),
                        "SingleFace": row.get("SingleFace", ""),
                        "Quality": row.get("Quality", ""),
                        "Artifact": row.get("Artifact", ""),
                    }
                    decision = "KEEP" if config.meets_criteria(image_type, answers) else "DISCARD"
                    selected = row.get("Selected", "") or None
                    explanation = row.get("Artifact_Explanation", "")
                else:
                    answers, decision, selected, explanation = None, None, None, ""
                type_states.append({
                    "path": path, "answers": answers, "decision": decision,
                    "selected": selected, "explanation": explanation,
                })
            self.states[image_type] = type_states

    def _resolve_starting_point(self):
        for image_type in self.type_order:
            states = self.states[image_type]
            first_unanswered = next((i for i, s in enumerate(states) if s["answers"] is None), None)
            if first_unanswered is not None:
                self._enter_type(image_type, first_unanswered, "questions")
                return

            all_selected = all(s["selected"] not in (None, "") for s in states)
            if not all_selected:
                self._enter_type(image_type, len(states), "selection")
                return

        self._finish_identity()

    # -----------------------------------------------------------------
    # Type/image navigation
    # -----------------------------------------------------------------
    def _enter_type(self, image_type, pos, mode):
        self.current_type = image_type
        self.current_pos = pos
        self.mode = mode
        if mode == "questions":
            self._render_question_image()
        else:
            self._render_selection()
        self._refresh_overall_progress()

    def _refresh_overall_progress(self):
        try:
            df = csv_manager.load_dataframe(self.csv_path)
            done = len(df)
        except Exception:
            done = 0
        self.annotation_page.set_overall_progress(done, self.total_images_all)

    def _render_question_image(self):
        identity = self.current_identity
        image_type = self.current_type
        states = self.states[image_type]
        pos = self.current_pos
        path = states[pos]["path"]

        self.annotation_page.show_questions_mode()
        self.annotation_page.set_header(identity.id, identity.celebrity, image_type, pos, len(states))
        self.annotation_page.load_image(path)

        meta_key = (identity.id, image_type, os.path.basename(path))
        self.annotation_page.set_source_info(self.metadata.get(meta_key))

        self.annotation_page.set_reference_images(
            identity.real_images, exclude_path=path if image_type == "Real" else None
        )
        self.annotation_page.set_search_context(identity.celebrity)

        question_defs = config.REAL_QUESTIONS if image_type == "Real" else config.FAKE_QUESTIONS
        extra = None if image_type == "Real" else config.FAKE_EXTRA_QUESTION
        show_explanation = (image_type == "Fake")
        self.annotation_page.build_questions(question_defs, extra, show_explanation=show_explanation)

        if states[pos]["answers"]:
            self.annotation_page.set_answers(states[pos]["answers"])
        if show_explanation:
            self.annotation_page.set_explanation(states[pos].get("explanation", ""))

        can_back = not (image_type == self.type_order[0] and pos == 0)
        self.annotation_page.set_back_enabled(can_back)
        self.annotation_page.set_primary_button(
            "Next Image \u2192", enabled=self.annotation_page.all_answered()
        )
        self.annotation_page.set_review_banner(
            self.browsing_identity_id is not None,
            f"{identity.id} \u2014 {identity.celebrity}"
        )
        self.image_start_time = datetime.now()

    def _render_selection(self):
        identity = self.current_identity
        image_type = self.current_type
        states = self.states[image_type]

        candidates = [s["path"] for s in states if s["decision"] == "KEEP"]
        already_selected = [os.path.basename(s["path"]) for s in states if s.get("selected") == "Yes"]
        if not already_selected and len(candidates) <= config.MAX_KEEP_PER_TYPE:
            already_selected = [os.path.basename(p) for p in candidates]

        self.annotation_page.show_selection_mode()
        self.annotation_page.set_header(identity.id, identity.celebrity, image_type, len(states), len(states))
        self.annotation_page.selection_view.load(
            candidates, image_type, config.MAX_KEEP_PER_TYPE, already_selected
        )
        self.annotation_page.set_back_enabled(True)
        self.annotation_page.set_primary_button("Confirm Selection \u2192", enabled=True)
        self.annotation_page.set_review_banner(
            self.browsing_identity_id is not None,
            f"{identity.id} \u2014 {identity.celebrity}"
        )

    # -----------------------------------------------------------------
    # Button handlers
    # -----------------------------------------------------------------
    def _on_primary_clicked(self):
        if self.mode == "questions":
            self._commit_current_answer_and_advance()
        else:
            self._confirm_selection_and_advance()

    def _commit_current_answer_and_advance(self):
        if not self.annotation_page.all_answered():
            return

        identity = self.current_identity
        image_type = self.current_type
        states = self.states[image_type]
        pos = self.current_pos
        path = states[pos]["path"]

        answers, _score = self.annotation_page.collect_answers()
        explanation = self.annotation_page.get_explanation() if image_type == "Fake" else ""

        # Used only internally to build the "choose your best photos" screen -
        # never written to the CSV. See config.meets_criteria().
        decision = "KEEP" if config.meets_criteria(image_type, answers) else "DISCARD"

        states[pos]["answers"] = answers
        states[pos]["decision"] = decision
        states[pos]["selected"] = None
        states[pos]["explanation"] = explanation

        row = {
            "ID": identity.id,
            "Celebrity": identity.celebrity,
            "Image": os.path.basename(path),
            "Type": image_type,
            "Identity": answers.get("Identity", ""),
            "Reliable": answers.get("Reliable", ""),
            "SingleFace": answers.get("SingleFace", ""),
            "Quality": answers.get("Quality", ""),
            "Artifact": answers.get("Artifact", ""),
            "Artifact_Explanation": explanation,
            "Selected": "",
            "AnnotationStart": self.image_start_time.isoformat(timespec="seconds") if self.image_start_time else "",
            "AnnotationEnd": datetime.now().isoformat(timespec="seconds"),
        }
        csv_manager.upsert_row(self.csv_path, row)

        if pos + 1 < len(states):
            self._enter_type(image_type, pos + 1, "questions")
        else:
            self._enter_type(image_type, len(states), "selection")

    def _confirm_selection_and_advance(self):
        chosen, has_candidates = self.annotation_page.selection_view.get_selection_state()
        if has_candidates and len(chosen) == 0:
            self.annotation_page.selection_view.show_empty_selection_prompt()
            return
        self._apply_selection(chosen)

    def _force_continue_empty_selection(self):
        """Called when the annotator clicks 'Continue Anyway' on the soft
        empty-selection reminder. There is no hard minimum - this always
        succeeds."""
        self._apply_selection([])

    def _apply_selection(self, chosen):
        identity = self.current_identity
        image_type = self.current_type
        states = self.states[image_type]

        csv_manager.update_selected(self.csv_path, identity.id, image_type, chosen)
        for s in states:
            s["selected"] = "Yes" if os.path.basename(s["path"]) in chosen else "No"

        idx = self.type_order.index(image_type)
        if idx + 1 < len(self.type_order):
            next_type = self.type_order[idx + 1]
            self._enter_type(next_type, 0, "questions")
        else:
            self._finish_identity()

    def _on_back_clicked(self):
        if self.mode == "selection":
            image_type = self.current_type
            states = self.states[image_type]
            self._enter_type(image_type, len(states) - 1, "questions")
            return

        image_type = self.current_type
        pos = self.current_pos
        if pos > 0:
            self._enter_type(image_type, pos - 1, "questions")
            return

        idx = self.type_order.index(image_type)
        if idx > 0:
            prev_type = self.type_order[idx - 1]
            self._enter_type(prev_type, len(self.states[prev_type]), "selection")

    def _finish_identity(self):
        identity = self.current_identity
        was_new = identity.id not in self.completed_ids_set
        progress_manager.mark_identity_complete(self.annotator_name, identity.id)
        self.completed_ids_set.add(identity.id)

        if self.browsing_identity_id is not None:
            self._return_from_browse()
            return

        if was_new:
            self.completed_count += 1
        self.annotation_page.set_progress(self.completed_count, self.total_identities)
        self._advance_to_next_identity()

    # -----------------------------------------------------------------
    # Review / browse-completed-identities mode
    # -----------------------------------------------------------------
    def _open_browse_page(self):
        rows = []
        for identity in self.identities_all:
            is_completed = identity.id in self.completed_ids_set
            status = "Completed" if is_completed else "Not reached yet"
            rows.append((identity.id, identity.celebrity, status, is_completed))
        self.browse_page.populate(rows)
        self.stack.setCurrentWidget(self.browse_page)

    def _close_browse_page(self):
        self.stack.setCurrentWidget(self.annotation_page)

    def _jump_to_identity(self, identity_id):
        if self.browsing_identity_id is None:
            self._pre_browse_identity = self.current_identity

        self.browsing_identity_id = identity_id
        identity_obj = next((i for i in self.identities_all if i.id == identity_id), None)
        if identity_obj is None:
            self._return_from_browse()
            return

        self.current_identity = identity_obj
        self._load_identity_state(identity_obj)
        self.stack.setCurrentWidget(self.annotation_page)

        if self.type_order:
            self._enter_type(self.type_order[0], 0, "questions")
        else:
            self._return_from_browse()

    def _exit_review_mode(self):
        self._return_from_browse()

    def _return_from_browse(self):
        self.browsing_identity_id = None
        original = self._pre_browse_identity
        self._pre_browse_identity = None
        if original is None:
            self._advance_to_next_identity()
            return
        self.current_identity = original
        self._load_identity_state(original)
        self._resolve_starting_point()

    # -----------------------------------------------------------------
    def closeEvent(self, event):
        event.accept()
