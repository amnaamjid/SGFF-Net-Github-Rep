# How to Use the Annotation Tool

Thank you for helping with this project! Follow these steps in order.
It looks like a lot, but steps 1-3 are one-time setup — after that, you
just double-click one file to start working.

---

## Step 1: Install Python (skip if you already have it)

1. Go to **https://www.python.org/downloads/**
2. Click the big yellow **"Download Python"** button.
3. Open the file you downloaded and run it.
4. **Important:** on the very first install screen, check the box that
   says **"Add Python to PATH"** before clicking Install. If you miss
   this, Python won't work properly.
5. Finish the installation.

*(Mac users: Python is often already installed. If step 3 below gives
an error, install Python the same way from the link above.)*

## Step 2: Unzip the folder

You should have received a file like `AnnotationTool.zip`.

- **Windows:** right-click it → "Extract All" → choose a location you'll
  remember (like your Desktop) → Extract.
- **Mac:** just double-click the zip file.

You'll now have a folder called something like `DeepfakeAnnotationTool`.
Open it.

## Step 3: Start the app

- **Windows:** double-click **`START_HERE_Windows.bat`**
- **Mac:** double-click **`START_HERE_Mac_Linux.command`**
  (If your Mac blocks it the first time: right-click the file → Open →
  click "Open" again to confirm. You only need to do this once.)

A black window will appear and do some one-time setup (this can take a
minute or two the first time only). Then the annotation tool will open.

> If nothing happens or you see an error, take a screenshot and send it
> to the project admin - don't worry, this is easy to fix.

## Step 4: Enter your name

When the app opens, type the **exact name the admin gave you**
(for example `Annotator1`). Use this **exact same name every single
time** you open the app - this is how it remembers your progress and
lets you continue where you left off.

Click **Start / Resume**.

## Step 5: Read the introduction screen

Before annotation begins, you'll see a short screen explaining the
dataset and the annotation rules. Give it a quick read, then click
**"I Understand — Start Annotating"**. You'll see a short version of
these same rules again on the annotation screen itself, so you don't
need to memorize anything.

## Step 6: Annotate

For each image you'll see:

- **The image** in the middle, with zoom buttons below it.
- A **Reference Photo** on the right - a known real photo of the same
  person, so you can compare faces. Use the ← / → arrows if there's
  more than one.
- **Image Source** info (if available) - where the image came from, with
  a link you can click to check it, and a "Copy Link" button as backup.
- **Search buttons** (Images / Wikipedia / Web) if you want to look the
  person up yourself.
- **Questions** to answer with Yes/No.
- For fake images, an optional box to explain what looked artificial.

**Buttons at the bottom:**
- **← Back** - go back and review or change your answer on the previous
  image, any time.
- **Next Image →** - saves your answer and moves on. This button is
  greyed out until you've answered every question.

After you finish all the images for one person, you'll be asked to
click on your best photos (up to 3 - a green checkmark shows what's
selected). **You are not required to select anything** - if none of the
images seem right, you can click Confirm with none selected. If you try
to continue without picking any and some were available, you'll just
get a friendly reminder asking if you're sure - either click "Continue
Anyway" or "Go Back / Review" to change your mind. Nothing is ever
forced.

## Step 7: Taking breaks

**You can close the app at any time** - just close the window normally.
Nothing is lost. When you reopen it and type your name again, you'll
continue from exactly where you stopped.

## Step 8: When you're done (or asked to send progress)

Your answers are saved automatically in a file, and that file is the
**only thing** you need to send back. You do **not** need to send the
whole folder, the dataset, or anything else.

1. Open the app's folder.
2. Open the `results` folder inside it.
3. You'll find a file named after you, for example: **`Annotator1.csv`**
4. Send **just that one file** to the admin (email, shared drive,
   WhatsApp, however they asked for it).

That's it - thank you again for your work!
