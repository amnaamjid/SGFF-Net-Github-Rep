# Deepfake Dataset Annotation Tool

A desktop app (PySide6) for three annotators to independently review a
real/fake face dataset, image by image, with automatic scoring, a
"pick your best 3" step, crash-safe saving, resume support, and a
majority-voting script to merge the three annotators' work into a final
accepted dataset.

---

## 1. Folder structure

```
DeepfakeAnnotationTool/
├── app.py                 <- run this to start the GUI
├── config.py               (edit if you need to change rules/paths)
├── gui.py
├── dataset_loader.py
├── csv_manager.py
├── progress_manager.py
├── image_viewer.py
├── selection_view.py       (click-to-select "choose your best 3" screen)
├── reference_panel.py      (fixed reference-photo panel)
├── metadata_builder.py     (links downloaded images to their source)
├── metadata_loader.py
├── majority_vote.py       <- run this AFTER all annotators finish
├── requirements.txt
├── icons/
├── results/                (annotator CSVs are written here)
├── progress/                (resume state is written here)
└── Dataset/                 <- put your dataset here
```

## 2. Put your dataset in place

Copy your dataset into the `Dataset/` folder so it looks like:

```
Dataset/
├── ID0001_Tom_Cruise/
│   ├── Real/
│   │   ├── real1.jpg
│   │   └── ...
│   └── Fake/
│       ├── fake1.jpg
│       └── ...
├── ID0002_Emma_Watson/
│   ├── Real/
│   └── Fake/
...
```

- The folder name must be `<ID>_<Name>` (underscore-separated). `ID0001_Tom_Cruise`
  becomes ID `ID0001`, celebrity `Tom Cruise`.
- Subfolders must be named exactly `Real` and `Fake`.
- Supported image types: `.jpg .jpeg .png .bmp .webp`
- Identities with zero images in both folders are skipped automatically.
- An identity with images in only one of Real/Fake is fine — the tool
  simply skips the empty side.

## 3. (Optional but recommended) Show image source info to annotators

If you have `candidate_urls` and `download_log` sheets from your own
search/download pipeline (search results with `Source_Page_URL`,
`Trust_Tier`, etc., and a log of which candidate got saved as which local
filename), the tool can automatically show that info next to every image
so annotators can judge "Reliable source?" properly.

1. Copy your two sheets into this `DeepfakeAnnotationTool/` folder, named
   exactly (any of `.csv`, `.tsv`, or `.xlsx` works):
   - `candidate_urls.csv`
   - `download_log.csv`
   (a `search_queries.csv` is fine to include too, but isn't required)

2. Run:
   ```bash
   python metadata_builder.py
   ```
   This reads both sheets, matches every downloaded image file back to the
   search result it came from, and writes `image_metadata.csv`.

3. That's it — `app.py` automatically detects `image_metadata.csv` and
   shows an **"Image Source"** panel next to each image with its title,
   domain, trust tier, the search query that found it, and a button to
   open the original source page in a browser. If an image has no match,
   the panel just says "No source info available" instead of crashing.

   Re-run `metadata_builder.py` any time you add more downloaded images.

## 4. Install (one-time setup)

You need Python 3.10+ installed. Then, from inside the
`DeepfakeAnnotationTool` folder:

```bash
python -m venv venv
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
```

## 5. Run the annotation tool

```bash
python app.py
```

1. A welcome screen asks for the annotator's name (e.g. `Annotator1`,
   `Annotator2`, `Annotator3`). Use the **same name every time** so the
   tool can resume correctly and write to the same results file.
2. An **introduction screen** explains the dataset, the annotator's
   task, and the annotation rules (see below) before annotation begins.
   A short version of the same rules stays visible as a permanent
   reminder banner on the annotation screen itself.
3. The identities are shown in a randomized order that is unique to,
   but reproducible for, that annotator name (reduces order bias while
   staying reproducible if the app is restarted).
4. For each identity, every image is shown one at a time with:
   - The image itself, with zoom controls.
   - A **fixed Reference Photo panel** showing one of the identity's
     known-real photos, with ← / → to cycle through others if there are
     more. It stays visible the whole time you're on that identity - it
     never disappears when you move between images.
   - An **"Image Source"** panel (if you ran `metadata_builder.py` - see
     step 3): title, domain, trust tier, and a clickable **"Open source
     page"** link, plus a **"Copy Link"** button as a fallback in case a
     default browser isn't configured on the annotator's machine.
   - Three one-click **search shortcuts** (Images / Wikipedia / Web) for
     the identity's name, for quick verification.
   - The Yes/No questions for that image type. Fake images also get an
     **Explanation / Evidence** text box to note what looked artificial
     (optional, but encouraged - it's saved to the CSV).
5. **Back and Next are always available.** Click **← Back** any time to
   revisit and change a previous image's answers - even after reaching
   the "choose your best photos" step. Editing an earlier answer
   automatically recalculates which images qualify.
6. After all Real (then all Fake) images of an identity are answered:
   - If more than 3 images met the annotation rules, an embedded
     **selection screen** shows thumbnails - **click a photo directly to
     select or deselect it** (no separate checkboxes). A live
     **"Selected: X / 3"** counter is always visible, and you can't
     select more than the limit.
   - If 3 or fewer met the criteria, they're pre-checked automatically -
     just glance and click "Confirm Selection".
   - **There is no required minimum.** Annotators can select zero images
     if none seem right. Trying to continue with zero selected (when
     some were available) shows a friendly, non-blocking reminder with
     "Continue Anyway" / "Go Back" buttons - never a hard restriction.
7. **Review Completed Identities**: a button in the header lets you jump
   back into any identity you've already finished, review or change your
   answers, and you'll return to exactly the image you were on before -
   even mid-identity.
8. **Save & Exit** button in the header (or just close the window/OS
   controls at any time) - everything is already saved, there's nothing
   to lose.
9. **The app can be minimized, resized, or closed at any time** - there
   are no popup windows anywhere that can get lost or block the app. The
   one deliberate exception: the "recommended you select at least one
   image" reminder appears as an inline banner on the same screen (not a
   separate window) - this is intentional, since a message that can
   never be a separate window can also never get lost behind one. It's
   also just a reminder, not a restriction - see point 6 above.
10. Every answer is written to `results/<AnnotatorName>.csv`
   **immediately** when "Next"/"Confirm" is clicked. If the app is closed
   (or crashes) mid-identity, reopening it with the same name resumes at
   **the exact next image**, not the start of that identity or the
   start of the dataset. A small **"Overall progress: image X of Y"**
   line in the header tracks this across the whole dataset, alongside
   the per-identity progress bar at the bottom.

### CSV output columns

```
ID, Celebrity, Image, Type, Identity, Reliable, SingleFace, Quality,
Artifact, Artifact_Explanation, Selected,
AnnotationStart, AnnotationEnd
```

Each annotator's raw Yes/No answers and their final photo choices are
saved as-is - there is deliberately **no computed Keep/Discard decision
in this file**. That judgment is made later, after combining all
annotators' files (see below).

- `Selected` = Yes/No/blank — the annotator's final choice after the
  "best photos" step (this is what feeds into majority voting). It's
  perfectly valid for this to be blank/No for every image of an
  identity - annotators are not required to select anything.

## 6. After all 3 annotators are done

Each annotator produces one CSV in `results/`:
```
results/
├── Annotator1.csv
├── Annotator2.csv
└── Annotator3.csv
```

Run:

```bash
python majority_vote.py
```

This produces `final_annotations.csv` with one row per image and:

- `FinalDecision = KEEP` if a **majority** of annotators marked it `Selected=Yes`.
- `FinalDecision = DISCARD` if a majority marked it `Selected=No` (or it was never selected).
- `FinalDecision = TIE` for genuine ties (e.g. 1-vs-1 disagreement with only
  2 annotators available for that image) — these are flagged for manual
  review rather than silently decided.
- If majority voting still leaves more than 3 KEEP images for one
  identity/type, only the top `VotesYes` (then highest `CriteriaMetFraction`
  - the share of annotators whose raw Yes/No answers met the annotation
  rules for that image) are kept, and the rest are downgraded to DISCARD
  with a note in `Reason`.

Custom paths are supported:
```bash
python majority_vote.py --results-dir results --output final_annotations.csv
python majority_vote.py --files results/Annotator1.csv results/Annotator2.csv results/Annotator3.csv
```

## 7. Packaging as a standalone Windows .exe (optional)

So annotators don't need to install Python themselves:

```bash
pip install pyinstaller
pyinstaller --noconsole --onefile --name DeepfakeAnnotator app.py
```

The `.exe` will appear in `dist/DeepfakeAnnotator.exe`. Distribute it
together with the `Dataset/`, `results/`, and `progress/` folders placed
next to the `.exe` (same folder). Each annotator runs the `.exe` on
their own machine (or you run three copies on one machine, one per
annotator name) and sends their `results/<Name>.csv` back to you.

> Note: PyInstaller must be run on the same OS you're targeting — build
> the `.exe` on Windows to distribute to Windows annotators.

## 8. Adjusting the rules

Everything about scoring, question text, and limits lives in
`config.py`:

- `REAL_QUESTIONS` / `FAKE_QUESTIONS` — edit question text or add/remove questions.
- `REAL_KEEP_SCORE` / `FAKE_KEEP_SCORE` — how many "Yes" answers are required to KEEP.
- `MAX_KEEP_PER_TYPE` — the "best N" cap (default 3).
- `seed_for_annotator()` — controls how identity order is randomized per annotator.

## 9. Troubleshooting: right-side panel got cut off / had to maximize to see it

Fixed. The source/reference/questions/explanation panel on the right now
scrolls independently if it doesn't fully fit in the current window
size - you'll see a scrollbar instead of missing content, and you no
longer need to maximize or resize the window to reach anything. The
Back/Next buttons always stay visible regardless of window size.

## 10. Troubleshooting: running under WSL (Windows Subsystem for Linux)

If you're running this inside WSL (e.g. via a `conda`/`venv` on
`\\wsl$` or a terminal like the one in VS Code), two WSL-specific issues
are handled automatically as of this version:

- **Links wouldn't open** ("Unable to detect a web browser to launch...")
  — WSL has no Linux browser installed by default. The app now detects
  WSL and hands links off to Windows itself (via `powershell.exe`), so
  they open in your normal Windows browser (Chrome/Edge/etc.).
- **The app closed/crashed after resizing/maximizing** (`The Wayland
  connection experienced a fatal error` / `xdg_surface buffer does not
  match...`) — this is a known bug in WSLg's Wayland display when a
  maximized window resizes. `app.py` automatically switches to the more
  stable X11/XCB display backend when it detects WSL - but **only if
  `libxcb-cursor0` is already installed**, since forcing XCB without it
  causes an immediate crash on startup instead. If you see a message in
  the terminal about this on launch, run:
  ```bash
  sudo apt install libxcb-cursor0
  ```
  and restart the app to get the crash fix. Until then, the app still
  runs fine on the default backend - the panel-scrolling fix below also
  removes most of the reason you'd need to resize/maximize in the first
  place, which was the main trigger.

If you ever need to override this (e.g. you've fixed Wayland another
way), set the environment variable yourself before running, and the
app will respect your choice instead:
```bash
QT_QPA_PLATFORM=wayland python3 app.py
```
