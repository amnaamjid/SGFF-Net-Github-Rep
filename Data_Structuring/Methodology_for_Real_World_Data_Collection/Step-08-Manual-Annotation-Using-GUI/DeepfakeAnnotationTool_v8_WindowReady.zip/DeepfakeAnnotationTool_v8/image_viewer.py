"""
image_viewer.py
A scrollable, zoomable image display widget.
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QScrollArea, QPushButton, QSizePolicy
)
from PySide6.QtGui import QPixmap
from PySide6.QtCore import Qt


class ImageViewer(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        self._pixmap = None
        self._scale = 1.0
        self._fit_mode = True

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.scroll_area = QScrollArea(self)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setAlignment(Qt.AlignCenter)

        self.image_label = QLabel("No image loaded")
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Ignored)
        self.scroll_area.setWidget(self.image_label)

        layout.addWidget(self.scroll_area, stretch=1)

        controls = QHBoxLayout()
        self.btn_zoom_out = QPushButton("Zoom Out (-)")
        self.btn_zoom_in = QPushButton("Zoom In (+)")
        self.btn_fit = QPushButton("Fit to Window")
        self.btn_original = QPushButton("Original Size")

        for b in (self.btn_zoom_out, self.btn_zoom_in, self.btn_fit, self.btn_original):
            controls.addWidget(b)

        layout.addLayout(controls)

        self.btn_zoom_in.clicked.connect(self.zoom_in)
        self.btn_zoom_out.clicked.connect(self.zoom_out)
        self.btn_fit.clicked.connect(self.fit_to_window)
        self.btn_original.clicked.connect(self.original_size)

    def load_image(self, path):
        pixmap = QPixmap(path)
        if pixmap.isNull():
            self.image_label.setText(f"Could not load image:\n{path}")
            self._pixmap = None
            return
        self._pixmap = pixmap
        self._fit_mode = True
        self._render()

    def _render(self):
        if self._pixmap is None:
            return
        if self._fit_mode:
            target_size = self.scroll_area.viewport().size()
            scaled = self._pixmap.scaled(
                target_size, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
        else:
            size = self._pixmap.size() * self._scale
            scaled = self._pixmap.scaled(
                size, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
        self.image_label.setPixmap(scaled)
        self.image_label.resize(scaled.size())

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._fit_mode:
            self._render()

    def zoom_in(self):
        self._fit_mode = False
        self._scale = min(self._scale * 1.25, 8.0)
        self._render()

    def zoom_out(self):
        self._fit_mode = False
        self._scale = max(self._scale / 1.25, 0.1)
        self._render()

    def fit_to_window(self):
        self._fit_mode = True
        self._render()

    def original_size(self):
        self._fit_mode = False
        self._scale = 1.0
        self._render()
