"""
app.py
Entry point for the Deepfake Dataset Annotation Tool.

Run with:
    python app.py
"""

import os
import sys


def _fix_wslg_crash():
    """
    Under WSL (WSLg), Qt's Wayland backend has a known bug where resizing a
    maximized window throws a fatal protocol error and kills the whole app
    ("xdg_surface buffer does not match the configured maximized state" /
    "The Wayland connection experienced a fatal error"). The fix is to use
    the older, more stable X11/XCB backend instead, which WSLg also
    supports - but XCB itself needs libxcb-cursor0 installed, and forcing
    XCB without it causes an immediate hard crash on startup instead. So
    we only switch if that library is actually present; otherwise we leave
    the default backend alone and just print instructions.
    """
    if os.environ.get("QT_QPA_PLATFORM"):
        return  # respect an explicit user choice
    try:
        with open("/proc/version", "r") as f:
            is_wsl = "microsoft" in f.read().lower()
    except Exception:
        is_wsl = False
    if not is_wsl:
        return

    import ctypes.util
    has_xcb_cursor = ctypes.util.find_library("xcb-cursor") is not None
    if not has_xcb_cursor:
        # Check common lib directories directly too, since find_library()
        # can miss libraries that aren't in the ldconfig cache yet.
        import glob
        has_xcb_cursor = bool(glob.glob("/usr/lib/*/libxcb-cursor.so*"))

    if has_xcb_cursor:
        os.environ["QT_QPA_PLATFORM"] = "xcb"
    else:
        print(
            "[Deepfake Annotation Tool] Running under WSL without libxcb-cursor0 installed.\n"
            "The app will run, but WSLg has a known bug that can crash it when the window\n"
            "is resized while maximized. To fix this permanently, run:\n"
            "    sudo apt install libxcb-cursor0\n"
            "and restart the app. Continuing with the default display backend for now..."
        )


_fix_wslg_crash()

from PySide6.QtWidgets import QApplication
from gui import MainWindow


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Deepfake Dataset Annotation Tool")

    window = MainWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
