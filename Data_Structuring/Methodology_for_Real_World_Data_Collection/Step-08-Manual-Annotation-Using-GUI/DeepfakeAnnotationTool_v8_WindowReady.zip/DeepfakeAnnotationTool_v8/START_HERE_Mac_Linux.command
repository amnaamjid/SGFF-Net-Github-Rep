#!/bin/bash
echo "============================================"
echo "  Deepfake Dataset Annotation Tool"
echo "============================================"
echo ""
echo "Checking / installing requirements (only takes a while the first time)..."
python3 -m pip install -r requirements.txt --quiet

if [ $? -ne 0 ]; then
    echo ""
    echo "Something went wrong installing requirements."
    echo "Make sure Python 3 is installed and try again."
    read -p "Press Enter to close..."
    exit 1
fi

echo ""
echo "Starting the application..."
echo ""
python3 app.py

echo ""
echo "The application has closed. Your work is already saved."
read -p "Press Enter to close..."
