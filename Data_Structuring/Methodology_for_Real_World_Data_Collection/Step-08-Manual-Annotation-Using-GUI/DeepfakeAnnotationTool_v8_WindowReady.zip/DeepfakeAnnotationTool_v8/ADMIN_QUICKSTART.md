# Admin Quick-Start: Sending This to Your Annotators

This is the short version. (For technical details/tweaking the rules,
see `README.md` instead.)

## Two ways to send this to annotators

**Option A - `.exe` (recommended): annotators install nothing at all.**
You build one `.exe` file once, on your own Windows machine, and send
that. Annotators just double-click it. See "Building the .exe" below.

**Option B - Python folder: annotators install Python once themselves.**
Faster for you to send right now, but each annotator needs to install
Python and double-click a `.bat`/`.command` launcher (see
`ANNOTATOR_GUIDE.md`). Use this if you can't get to a Windows machine,
or need to send something out immediately.

Both options produce the exact same app and the exact same
`results/<name>.csv` file at the end - pick whichever is easier for you.

---

## Option A: Building the .exe (do this once, on Windows - not WSL)

I can't build the `.exe` for you directly - it has to be built on the
same kind of computer it will run on (a real Windows machine), and I
only have a Linux environment here. But it's fully automated for you:

1. Copy this whole folder onto your **native Windows** filesystem
   (not inside WSL/Linux) - e.g. `C:\Users\YourName\AnnotationTool`.
   If you built/tested this via WSL before, copying it out of WSL into
   a normal Windows folder is important - PyInstaller run inside WSL
   would build a Linux program, not a Windows `.exe`.
2. Make sure your dataset is already inside `Dataset\` (see below).
3. Double-click **`BUILD_EXE_Windows.bat`** in a normal Windows Command
   Prompt (not WSL). It installs PyInstaller, builds the `.exe`, and
   automatically prepares a ready-to-send folder called
   **`Distribution_ForAnnotators`** containing:
   - `DeepfakeAnnotator.exe`
   - your `Dataset` folder
   - empty `results` / `progress` folders
   - `HOW TO USE.md` (the simple, no-Python-needed annotator guide)
4. Zip that `Distribution_ForAnnotators` folder and send it to your
   annotators. That's everything they need - no Python, no pip, no
   commands.

This only needs to be done once (or again if you change the dataset or
the code). Building takes a few minutes; the resulting `.exe` is
several hundred MB (Qt is bundled inside it) - that's normal for this
kind of app.

---

## Option B: Sending the Python version directly

### Before you send anything: add your dataset

1. Open this folder.
2. Copy your actual dataset folders (`ID0001_...`, `ID0002_...`, etc.)
   into the `Dataset` folder here, so it looks like:
   ```
   Dataset/
   ├── ID0001_Tom_Cruise/
   │   ├── Real/
   │   └── Fake/
   ├── ID0002_Emma_Watson/
   │   ├── Real/
   │   └── Fake/
   ...
   ```
3. (Optional) If you have `candidate_urls` and `download_log` sheets,
   copy them in too as `candidate_urls.csv` and `download_log.csv`, then
   run `python metadata_builder.py` once (see `README.md` section 3).
   This makes source links show up for annotators.

### Package it up

Zip the **whole folder** (with your dataset now inside it) and send that
one zip to each annotator - by email, Google Drive, WeTransfer, USB,
whatever's easiest. All three annotators can get the exact same zip.

**Do not** send them the `results/` or `progress/` folders from a
previous run - each annotator should start with those folders empty, so
delete anything in there before zipping if you've tested it yourself.

### What to tell each annotator

Just tell them two things:
1. "Unzip this and open **`ANNOTATOR_GUIDE.md`** - it explains everything."
2. **Give each annotator a different name to type in** (e.g. one is
   `Annotator1`, one is `Annotator2`, one is `Annotator3`). This matters -
   if two people use the same name, they'll overwrite each other's work.

That's the entire instruction they need - `ANNOTATOR_GUIDE.md` (included
in the zip) walks them through installing Python, running the app, and
sending their results back to you.

---

## Collecting results back (same for both options)

Each annotator will eventually send you **one file**:
`results/<TheirName>.csv` (e.g. `Annotator1.csv`).

1. Create a `results` folder somewhere on your own computer (e.g. inside
   a fresh copy of this tool, or anywhere convenient).
2. Put all three annotators' CSV files in there together.
3. Open a terminal in that folder and run:
   ```bash
   python majority_vote.py --results-dir results --output final_annotations.csv
   ```
   (or just `python majority_vote.py` if the files are in this project's
   own `results/` folder)
4. `final_annotations.csv` is your combined, final result - one row per
   image, with `FinalDecision` = KEEP / DISCARD / TIE (TIE means the
   annotators disagreed and it needs a manual look).

## They don't have to finish all at once

Annotators can close the app and reopen it any time - it picks up
exactly where they left off, even mid-image. You can ask them to send
you their CSV at any point (even partway through) if you want to check
progress; re-running `majority_vote.py` later with an updated file just
recalculates the result.
