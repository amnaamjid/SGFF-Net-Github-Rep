"""
progress_manager.py
Tracks which identities an annotator has FULLY completed, so the app can
resume exactly where they left off, even after a crash or closing the window.
"""

import os
import json
import config


def progress_path_for(annotator_name):
    safe_name = "".join(c for c in annotator_name.strip() if c.isalnum() or c in ("_", "-")) or "Annotator"
    return os.path.join(config.PROGRESS_DIR, f"{safe_name}_progress.json")


def load_progress(annotator_name):
    path = progress_path_for(annotator_name)
    if not os.path.exists(path):
        return {"completed_ids": []}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {"completed_ids": []}


def mark_identity_complete(annotator_name, identity_id):
    data = load_progress(annotator_name)
    if identity_id not in data["completed_ids"]:
        data["completed_ids"].append(identity_id)
    _save(annotator_name, data)


def is_identity_complete(annotator_name, identity_id):
    data = load_progress(annotator_name)
    return identity_id in data["completed_ids"]


def _save(annotator_name, data):
    path = progress_path_for(annotator_name)
    tmp_path = path + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp_path, path)
