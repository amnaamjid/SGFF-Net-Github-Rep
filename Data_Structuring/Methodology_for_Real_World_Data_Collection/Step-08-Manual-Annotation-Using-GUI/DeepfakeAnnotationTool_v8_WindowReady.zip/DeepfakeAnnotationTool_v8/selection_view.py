"""
selection_view.py
The "choose your best N" step, embedded (non-modal) inside the main window.
Click a photo directly to select/deselect it (highlighted border + check
mark) instead of using a separate checkbox. A live "Selected: X / N"
counter is always visible.
"""

import os
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QGridLayout, QScrollArea,
    QFrame, QPushButton
)
from PySide6.QtGui import QPixmap
from PySide6.QtCore import Qt

THUMB_SIZE = 150


class SelectableThumbnail(QWidget):
    def __init__(self, path, on_toggle):
        super().__init__()
        self.path = path
        self.filename = os.path.basename(path)
        self.selected = False
        self._on_toggle = on_toggle

        layout = QVBoxLayout(self)

        self.frame = QLabel()
        self.frame.setFixedSize(THUMB_SIZE, THUMB_SIZE)
        self.frame.setAlignment(Qt.AlignCenter)
        pix = QPixmap(path)
        if not pix.isNull():
            pix = pix.scaled(THUMB_SIZE - 10, THUMB_SIZE - 10, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.frame.setPixmap(pix)
        else:
            self.frame.setText("(preview unavailable)")

        self.check_label = QLabel(" ")
        self.check_label.setAlignment(Qt.AlignCenter)
        self.check_label.setStyleSheet("color: #2a7a2a; font-weight: bold; font-size: 13px;")

        self.name_label = QLabel(self.filename)
        self.name_label.setAlignment(Qt.AlignCenter)
        self.name_label.setStyleSheet("font-size: 10px; color: #555;")

        layout.addWidget(self.frame)
        layout.addWidget(self.check_label)
        layout.addWidget(self.name_label)
        self._update_style()

    def mousePressEvent(self, event):
        self._on_toggle(self)

    def set_selected(self, value):
        self.selected = value
        self._update_style()

    def _update_style(self):
        if self.selected:
            self.frame.setStyleSheet(
                "border: 4px solid #2a7a2a; border-radius: 6px; background: #eaffea;"
            )
            self.check_label.setText("\u2713 Selected")
        else:
            self.frame.setStyleSheet(
                "border: 2px solid #ccc; border-radius: 6px;"
            )
            self.check_label.setText(" ")


class SelectionView(QWidget):
    def __init__(self, on_continue_anyway):
        super().__init__()
        self.thumbnails = []
        self.max_keep = 3
        self._on_continue_anyway = on_continue_anyway

        layout = QVBoxLayout(self)

        self.info_label = QLabel("")
        self.info_label.setWordWrap(True)
        self.info_label.setStyleSheet("font-size: 15px; font-weight: bold;")
        layout.addWidget(self.info_label)

        self.counter_label = QLabel("")
        self.counter_label.setStyleSheet("font-size: 13px; font-weight: bold; color: #2a7a2a;")
        layout.addWidget(self.counter_label)

        self.warning_label = QLabel("")
        self.warning_label.setWordWrap(True)
        self.warning_label.setStyleSheet(
            "color: #b00020; font-weight: bold; background: #fff0f0; "
            "border: 1px solid #f0c0c0; border-radius: 4px; padding: 6px;"
        )
        self.warning_label.setVisible(False)
        layout.addWidget(self.warning_label)

        # Soft, non-blocking prompt shown only if the annotator tries to
        # continue with zero images selected while some were available.
        # This is a reminder, not a restriction - both buttons let them
        # proceed or reconsider, and neither can get "stuck".
        self.empty_prompt = QFrame()
        self.empty_prompt.setStyleSheet(
            "background: #fff6dd; border: 1px solid #e0c060; border-radius: 4px;"
        )
        empty_layout = QVBoxLayout(self.empty_prompt)
        empty_text = QLabel(
            "It's recommended that you select at least one image before continuing. "
            "Would you like to continue anyway or go back and review your selections?"
        )
        empty_text.setWordWrap(True)
        empty_buttons = QHBoxLayout()
        go_back_button = QPushButton("Go Back / Review")
        go_back_button.clicked.connect(self._hide_empty_prompt)
        continue_button = QPushButton("Continue Anyway")
        continue_button.clicked.connect(self._continue_anyway_clicked)
        empty_buttons.addStretch(1)
        empty_buttons.addWidget(go_back_button)
        empty_buttons.addWidget(continue_button)
        empty_layout.addWidget(empty_text)
        empty_layout.addLayout(empty_buttons)
        self.empty_prompt.setVisible(False)
        layout.addWidget(self.empty_prompt)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.grid_holder = QWidget()
        self.grid = QGridLayout(self.grid_holder)
        scroll.setWidget(self.grid_holder)
        layout.addWidget(scroll, stretch=1)

        hint = QLabel("Click a photo to select or deselect it.")
        hint.setStyleSheet("color: #777; font-size: 11px;")
        layout.addWidget(hint)

    def load(self, image_paths, image_type, max_keep, already_selected=None):
        self.max_keep = max_keep
        already_selected = set(already_selected or [])

        while self.grid.count():
            item = self.grid.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        self.thumbnails = []
        self.warning_label.setVisible(False)
        self.empty_prompt.setVisible(False)

        if image_paths:
            self.info_label.setText(
                f"{len(image_paths)} {image_type} image(s) met the annotation criteria. "
                f"Click your best {max_keep} (or fewer) - or none, if none seem right."
            )
        else:
            self.info_label.setText(
                f"No {image_type} images for this identity met the criteria. "
                f"There's nothing to select here - just click Confirm to continue."
            )

        for i, path in enumerate(image_paths):
            thumb = SelectableThumbnail(path, self._on_toggle)
            thumb.set_selected(os.path.basename(path) in already_selected)
            self.grid.addWidget(thumb, i // 4, i % 4)
            self.thumbnails.append(thumb)

        self._update_counter()

    def _on_toggle(self, thumb):
        if not thumb.selected:
            currently_selected = sum(1 for t in self.thumbnails if t.selected)
            if currently_selected >= self.max_keep:
                self._show_warning(
                    f"You can select at most {self.max_keep}. Click a selected photo to unselect it first."
                )
                return
        thumb.set_selected(not thumb.selected)
        self.warning_label.setVisible(False)
        self.empty_prompt.setVisible(False)
        self._update_counter()

    def _update_counter(self):
        n = sum(1 for t in self.thumbnails if t.selected)
        self.counter_label.setText(f"Selected: {n} / {self.max_keep}")

    def _show_warning(self, message):
        self.warning_label.setText(message)
        self.warning_label.setVisible(True)

    def show_warning(self, message):
        self._show_warning(message)

    def _hide_empty_prompt(self):
        self.empty_prompt.setVisible(False)

    def show_empty_selection_prompt(self):
        self.warning_label.setVisible(False)
        self.empty_prompt.setVisible(True)

    def _continue_anyway_clicked(self):
        self.empty_prompt.setVisible(False)
        self._on_continue_anyway()

    def get_selection_state(self):
        """Returns (chosen_filenames, has_candidates). There is no minimum
        requirement anymore - an empty chosen list is a completely valid
        result, it just triggers a one-time soft reminder (handled by the
        caller) the first time it happens for a given screen."""
        chosen = [t.filename for t in self.thumbnails if t.selected]
        has_candidates = len(self.thumbnails) > 0
        return chosen, has_candidates
