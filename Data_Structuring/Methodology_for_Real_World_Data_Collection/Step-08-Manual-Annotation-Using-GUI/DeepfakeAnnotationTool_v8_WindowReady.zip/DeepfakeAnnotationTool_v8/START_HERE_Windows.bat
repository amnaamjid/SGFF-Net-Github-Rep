@echo off
title Deepfake Annotation Tool
echo ============================================
echo   Deepfake Dataset Annotation Tool
echo ============================================
echo.
echo Checking / installing requirements (only takes a while the first time)...
python -m pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo.
    echo Something went wrong installing requirements.
    echo Make sure Python is installed and try again.
    echo If you just installed Python, you may need to restart your computer first.
    pause
    exit /b 1
)

echo.
echo Starting the application...
echo.
python app.py

echo.
echo The application has closed. Your work is already saved.
pause
