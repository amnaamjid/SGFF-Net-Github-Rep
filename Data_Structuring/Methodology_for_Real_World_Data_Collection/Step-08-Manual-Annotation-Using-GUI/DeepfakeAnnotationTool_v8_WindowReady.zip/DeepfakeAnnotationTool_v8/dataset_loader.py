"""
dataset_loader.py
Scans the Dataset/ folder and builds an ordered list of identities,
each with its list of real and fake images.
"""

import os
import random
import config


class Identity:
    def __init__(self, identity_id, celebrity_name, folder_path):
        self.id = identity_id                # e.g. "ID0001"
        self.celebrity = celebrity_name      # e.g. "Tom Cruise"
        self.folder_path = folder_path
        self.real_images = []                # list of absolute paths
        self.fake_images = []

    def __repr__(self):
        return f"<Identity {self.id} {self.celebrity} real={len(self.real_images)} fake={len(self.fake_images)}>"


def _list_images(folder):
    if not os.path.isdir(folder):
        return []
    files = [
        f for f in sorted(os.listdir(folder))
        if f.lower().endswith(config.VALID_IMAGE_EXTENSIONS)
    ]
    return [os.path.join(folder, f) for f in files]


def parse_identity_folder_name(folder_name):
    """
    Folder names look like 'ID0001_Tom_Cruise'.
    Returns (identity_id, celebrity_name).
    Falls back gracefully if the naming convention differs.
    """
    parts = folder_name.split("_", 1)
    if len(parts) == 2:
        identity_id, rest = parts
        celebrity = rest.replace("_", " ").strip()
    else:
        identity_id = folder_name
        celebrity = folder_name
    return identity_id, celebrity


def load_dataset(dataset_dir=None):
    """
    Returns a list of Identity objects, sorted alphabetically by folder name
    (this is the canonical order; per-annotator randomisation happens later).
    """
    dataset_dir = dataset_dir or config.DATASET_DIR
    identities = []

    if not os.path.isdir(dataset_dir):
        return identities

    for entry in sorted(os.listdir(dataset_dir)):
        full_path = os.path.join(dataset_dir, entry)
        if not os.path.isdir(full_path):
            continue

        identity_id, celebrity = parse_identity_folder_name(entry)
        identity = Identity(identity_id, celebrity, full_path)
        identity.real_images = _list_images(os.path.join(full_path, config.REAL_FOLDER_NAME))
        identity.fake_images = _list_images(os.path.join(full_path, config.FAKE_FOLDER_NAME))

        # Skip identities with no images at all
        if identity.real_images or identity.fake_images:
            identities.append(identity)

    return identities


def order_for_annotator(identities, annotator_name):
    """
    Returns a NEW list of identities shuffled with a reproducible,
    annotator-specific seed (reduces order bias between annotators while
    remaining reproducible if the tool is restarted).
    """
    rng = random.Random(config.seed_for_annotator(annotator_name))
    shuffled = identities[:]
    rng.shuffle(shuffled)
    return shuffled
