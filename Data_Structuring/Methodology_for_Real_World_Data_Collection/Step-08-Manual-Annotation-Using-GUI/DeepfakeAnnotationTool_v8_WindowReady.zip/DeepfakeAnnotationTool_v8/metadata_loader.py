"""
metadata_loader.py
Loads image_metadata.csv (produced by metadata_builder.py) into a lookup
dict the GUI can use to show each image's source info.
"""

import os
import pandas as pd
import config


def load_metadata():
    """Returns dict: (identity_id, image_type, filename) -> info dict.
    Returns an empty dict if image_metadata.csv doesn't exist yet
    (the GUI just shows 'no source info available' in that case)."""
    if not os.path.exists(config.METADATA_FILE):
        return {}

    df = pd.read_csv(config.METADATA_FILE, dtype=str).fillna("")
    lookup = {}
    for _, row in df.iterrows():
        key = (str(row.get("ID", "")), str(row.get("Type", "")), str(row.get("Image", "")))
        lookup[key] = row.to_dict()
    return lookup
